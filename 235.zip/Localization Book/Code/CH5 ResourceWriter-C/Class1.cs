using System;
using System.Resources;
using System.Collections;

namespace CH5ResourceWriter_C
{
	/// <summary>
	/// ResourceWriter and reader example
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
      ResourceWriter Rw = new ResourceWriter("CH5Rw.resources");

      Rw.AddResource("key 1", "First value");
      Rw.AddResource("key 2", "Second value");
      Rw.AddResource("key 3", "Third value");
      Rw.Generate();
      Rw.Close();

      ResourceReader Rr = new ResourceReader("CH5Rw.resources");
      IDictionaryEnumerator RrEn = Rr.GetEnumerator();
      while (RrEn.MoveNext())
      {
         Console.WriteLine("Name: {0} - Value: {1}", 
            RrEn.Key.ToString().PadRight(10, ' '), 
            RrEn.Value);
      }
      Rr.Close();

      Console.ReadLine();
		}
	}
}
