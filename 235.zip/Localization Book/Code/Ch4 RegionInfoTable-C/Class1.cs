using System;
using System.Globalization;

namespace Ch7RegionInfoTable_C
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{

      CultureInfo[] AllCultures;
  //    CultureInfo ACulture;
      RegionInfo Rg;

      AllCultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
         foreach (CultureInfo ACulture in AllCultures)
         {
            Rg = new RegionInfo(ACulture.LCID);
            Console.WriteLine(Rg.TwoLetterISORegionName.ToString().PadRight(5, ' ') + 
               "," + Rg.EnglishName.PadRight(40, ' ') + 
               "," + ACulture.LCID.ToString());
         }

      Console.ReadLine();
      }
	}
}
