using System;
using System.Globalization;
using System.Threading;

namespace CH7DateTimeFormatFrench_C
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
      CultureInfo MyCulture = new CultureInfo("fr-FR");
      DateTime MyDate = System.DateTime.Now;
      DateTimeFormatInfo dtf;

      Thread.CurrentThread.CurrentCulture = MyCulture;

      Console.WriteLine(MyDate.ToLongDateString());
      Console.WriteLine(MyDate.ToLongTimeString());
      Console.WriteLine(MyDate.ToShortDateString());
      Console.WriteLine(MyDate.ToShortTimeString());

      dtf = MyCulture.DateTimeFormat;
      //Change date and time separator
      dtf.DateSeparator = "\\";
      dtf.TimeSeparator = "&";

      Console.WriteLine();
      Console.WriteLine(MyDate.ToLongDateString());
      Console.WriteLine(MyDate.ToLongTimeString());
      Console.WriteLine(MyDate.ToShortDateString());
      Console.WriteLine(MyDate.ToShortTimeString());

      Console.ReadLine();

      
      }
	}
}
