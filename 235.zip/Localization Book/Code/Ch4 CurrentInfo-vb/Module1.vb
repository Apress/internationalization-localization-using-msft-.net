
Imports System.Globalization
Imports System.Threading

Module Module1

   Sub Main()

      Dim MyCulture As New CultureInfo("es-ES")
      Dim Myfmt As DateTimeFormatInfo
      Dim fmt1 As DateTimeFormatInfo

      Myfmt = MyCulture.DateTimeFormat
      fmt1 = DateTimeFormatInfo.CurrentInfo

      Console.WriteLine(Myfmt.GetMonthName(12))
      Console.WriteLine(fmt1.GetMonthName(12))
      Console.WriteLine(Thread.CurrentThread. _
                        CurrentCulture. _
                        DateTimeFormat. _
                        GetMonthName(12))





      Console.ReadLine()
   End Sub

End Module
