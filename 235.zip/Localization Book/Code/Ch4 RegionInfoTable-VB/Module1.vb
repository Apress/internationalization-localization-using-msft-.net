Imports System
Imports System.Globalization

Module Module1

   Sub Main()

      Dim AllCultures() As CultureInfo
      Dim ACulture As CultureInfo
      Dim Rg As RegionInfo
      Dim k As Integer

      AllCultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures)
      For Each ACulture In AllCultures
         Rg = New RegionInfo(ACulture.LCID)
         Console.WriteLine(Rg.TwoLetterISORegionName.ToString().PadRight(5, " ") + _
                              "," + Rg.EnglishName.PadRight(40, " ") + _
                              "," + ACulture.LCID.ToString())
      Next



      Console.ReadLine()
   End Sub

End Module
