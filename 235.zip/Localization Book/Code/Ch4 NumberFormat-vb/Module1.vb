Imports System.Globalization
Imports System.Threading


Module Module1

   Sub Main()

      Dim FRCulture As New CultureInfo("fr-FR")
      Dim MyCulture As New CultureInfo(Thread. _
                                       CurrentThread. _
                                       CurrentUICulture. _
                                       LCID)
      Dim Vnf As NumberFormatInfo

      Console.WriteLine(123456.ToString("c", MyCulture))

      Vnf = MyCulture.NumberFormat
      Vnf.CurrencyDecimalSeparator = ","
      Vnf.CurrencyGroupSeparator = "."
      Vnf.NumberDecimalSeparator = ","
      Vnf.NumberGroupSeparator = "."
      MyCulture.NumberFormat = Vnf

      Console.WriteLine(123456.ToString("C", MyCulture))

      MyCulture.NumberFormat = FRCulture.NumberFormat
      Console.WriteLine(123456.ToString("c", MyCulture))





      Console.ReadLine()

   End Sub

End Module
