
Imports System.Reflection

Module Module1

   Sub Main()
      Dim Index As Integer
      Dim ReflA As System.Reflection.Assembly
      Dim ReflA_Types() As Type
      Dim fname As String

    'MSCORLIB.DLL may be in a diffecernt directory that V1.0.3328 depending on your version of .NET
    fname = "C:\WINNT\Microsoft.NET\Framework\v1.0.3328\mscorlib.dll"
      ReflA = ReflA.LoadFrom(fname)
      ReflA_Types = ReflA.GetTypes()
      Console.WriteLine(fname)
      For Index = 0 To UBound(ReflA_Types)
         If ReflA_Types(Index).Namespace = "System.Resources" Or _
            ReflA_Types(Index).Namespace = "System.Globalization" Then
            Console.WriteLine("  Found -> " + ReflA_Types(Index).FullName)
            System.Threading.Thread.Sleep(100)
         End If

      Next

      Console.WriteLine("End")
      Console.ReadLine()
   End Sub

End Module
