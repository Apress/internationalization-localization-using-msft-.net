using System;
using System.Resources;

namespace CH7ResourceSet_C
{
	/// <summary>
	///  Resource set C# example
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
      ResourceSet Rs = new ResourceSet("ch5rr.resources");

      Console.WriteLine(Rs.GetString("first", true));
      Console.WriteLine(Rs.GetString("second", true));
      Console.WriteLine(Rs.GetString("third", true));
      Console.WriteLine(Rs.GetString("fourth", true));
      Console.WriteLine(Rs.GetString("not here", true));
      Console.WriteLine(Rs.GetDefaultReader().ToString());

      Rs.Close();
      Console.ReadLine();
		}
	}
}
