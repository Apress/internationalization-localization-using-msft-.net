Imports System
Imports System.Globalization
Imports System.Threading



Module Module1

   Sub Main()

      Dim MyCulture As CultureInfo = New CultureInfo("fr-FR")
      Dim MyDate As DateTime = Now()
      Dim dtf As DateTimeFormatInfo

      Thread.CurrentThread.CurrentCulture = MyCulture

      Console.WriteLine(MyDate.ToLongDateString())
      Console.WriteLine(MyDate.ToLongTimeString())
      Console.WriteLine(MyDate.ToShortDateString())
      Console.WriteLine(MyDate.ToShortTimeString())

      dtf = MyCulture.DateTimeFormat
      'Change date and time separator
      dtf.DateSeparator = "\"
      dtf.TimeSeparator = "&"

      Console.WriteLine()
      Console.WriteLine(MyDate.ToLongDateString())
      Console.WriteLine(MyDate.ToLongTimeString())
      Console.WriteLine(MyDate.ToShortDateString())
      Console.WriteLine(MyDate.ToShortTimeString())

      Console.ReadLine()
   End Sub

End Module
