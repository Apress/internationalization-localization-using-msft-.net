Imports System
Imports System.Resources

Module Module1

  Sub Main()

    Dim Rs As New ResourceSet("ch5rr.resources")

    Console.WriteLine(Rs.GetString("first", True))
    Console.WriteLine(Rs.GetString("second", True))
    Console.WriteLine(Rs.GetString("third", True))
    Console.WriteLine(Rs.GetString("fourth", True))
    Console.WriteLine(Rs.GetString("not here", True))
    Console.WriteLine(Rs.GetDefaultReader.ToString())

    Rs.Close()
    Console.ReadLine()
  End Sub

End Module
