Option Strict On

Imports System
Imports System.Globalization
Imports System.Resources
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging

'Make it a friend because we do not want to expose it outside of this assembly.
'Like making a class private in COM
Friend Class ResUtil

  Public Class InvalidTable
    Inherits System.Exception

    Sub New(ByVal Message As String)
      MyBase.New(Message)
    End Sub

  End Class

  Private m_ResFile As String
  Private m_SaveFile As String
  Private m_ResType As ResTypes
  Private m_PicCol As Collection

  '--------- Constructors / Destructors ----------------
  Public Sub New()

    'Default to binary file.  Default name
    m_ResType = Consts.ResTypes.BinType
    m_ResFile = "BinResource.resources"
    m_SaveFile = m_ResFile
    m_PicCol = New Collection()

  End Sub
  Public Sub New(ByVal ResourceFilename As String)

    m_ResType = Consts.ResTypes.BinType
    m_ResFile = ResourceFilename
    m_SaveFile = m_ResFile
    m_PicCol = New Collection()

  End Sub
  Public Sub New(ByVal ResourceFilename As String, ByVal RType As ResTypes)

    m_ResType = RType
    m_ResFile = ResourceFilename
    m_SaveFile = m_ResFile
    m_PicCol = New Collection()

  End Sub

  '--------- Public properties and functions -----------
  Public Property FileName() As String
    Get
      Return m_ResFile
    End Get
    Set(ByVal rhs As String)
      m_ResFile = rhs
    End Set
  End Property
  Public Property ResourceType() As ResTypes
    Get
      Return m_ResType
    End Get
    Set(ByVal rhs As ResTypes)
      m_ResType = rhs
    End Set
  End Property
  Public ReadOnly Property Pics() As Collection
    Get
      Return m_PicCol
    End Get
  End Property
  Public Property OutputFileName() As String
    Get
      Return m_SaveFile
    End Get
    Set(ByVal Value As String)
      m_SaveFile = Value
    End Set
  End Property


  Public Sub GetData(ByRef ResData As DataTable, ByVal append As Boolean)

    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    'Make sure that memory is clear
    If Not append Then
      ResData.Clear()
      While m_PicCol.Count > 0
        m_PicCol.Remove(1)
      End While
    End If

    Select Case m_ResType
      Case Consts.ResTypes.TextType
        Try
          FillFromTextFile(ResData)
        Catch ex As Exception
          Throw ex
        End Try

      Case Consts.ResTypes.XMLType
        Try
          FillFromXMLFile(ResData)
        Catch ex As Exception
          Throw ex
        End Try

      Case Consts.ResTypes.BinType
        Try
          FillFromBinaryFile(ResData)
        Catch ex As Exception
          Throw ex
        End Try
    End Select

  End Sub
  Public Sub SaveData(ByVal ResData As DataTable, ByVal Pics As Collection, _
                      ByVal ResType As ResTypes)

    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    m_PicCol = Pics
    Select Case ResType
      Case Consts.ResTypes.TextType
        SaveToTextFile(ResData)
      Case Consts.ResTypes.XMLType
        SaveToXMLFile(ResData)
      Case Consts.ResTypes.BinType
        SaveToBinaryFile(ResData)
    End Select

  End Sub

  '--------- private internal functions ----------------
  Private Sub FillFromBinaryFile(ByRef ResData As DataTable)

    'Do not try anything if we are handed an invalid table
    'This is better than a try catch block.  Avoid errors when possible.  
    'Do not just catch them.
    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    Try
      Dim ResReader As New ResourceReader(m_ResFile)
      Dim En As IDictionaryEnumerator = ResReader.GetEnumerator()

      'Iterate over the resource file
      'Add a row for each resource string and put key and value in 
      'correct(columns)Don't forget! ResX resource files can contain 
      'pictures.  We only want the strings!
      While (En.MoveNext)
        If En.Value.GetType Is GetType(String) Then
          ResData.Rows.Add(ResData.NewRow)
          ResData.Rows(ResData.Rows.Count - 1)(KeyCol) = En.Key
          ResData.Rows(ResData.Rows.Count - 1)(TextCol) = En.Value

        ElseIf En.Value.GetType Is GetType(Bitmap) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        ElseIf En.Value.GetType Is GetType(Icon) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        ElseIf En.Value.GetType Is GetType(Image) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        End If
      End While

      ResReader.Close()

    Catch ex As Exception
      Throw ex

    End Try

  End Sub
  Private Sub SaveToBinaryFile(ByVal ResData As DataTable)
    Dim Fname As String
    Dim Pic As ResImage

    'Do not try anything if we are handed an invalid table
    'This is better than a try catch block.  Avoid errors when possible.  
    'Do not just catch them.
    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    'Split the filename and make it a text file
    Dim File_Info As New FileInfo(m_SaveFile)
    Fname = File_Info.FullName + ".resources"

    Try
      'This will write over the exisiting file!!
      Dim ResWriter As New ResourceWriter(Fname)
      Dim ResKey As String
      Dim ResVal As String
      Dim ResRow As DataRow


      'Iterate over the rows in the table and add to the resource file
      For Each ResRow In ResData.Rows
        ResKey = ResRow(KeyCol).ToString
        ResVal = ResRow(TextCol).ToString
        ResWriter.AddResource(ResKey, ResVal)
      Next

      'Save the pictures
      For Each Pic In m_PicCol
        ResWriter.AddResource(Pic.Name, Pic.Image)
      Next

      'Write out the resource file and close it.
      ResWriter.Generate()
      ResWriter.Close()

    Catch ex As Exception
      Throw ex

    End Try

  End Sub
  Private Sub FillFromTextFile(ByRef ResData As DataTable)
    Dim ResKey As String
    Dim ResVal As String
    Dim ResComment As String
    Dim ResRow As DataRow

    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    Try
      Dim MyStream As New StreamReader(m_ResFile)
      Dim MyLine As String
      Dim pos As Integer

      'Any string with a comment marker is considered a comment.  
      'Resgen thinks so too.
      While (True)
        MyLine = MyStream.ReadLine()
        If MyLine Is Nothing Then Exit While
        If MyLine <> "" Then
          pos = InStr(MyLine, ";")
          If pos < 2 Then   ' >=2 is an Ambiguous line
            If pos = 1 Then
              'This line is a comment so digest it as such
              ResComment = MyLine.ToString.TrimStart(CommentChar)
            End If

            If pos = 0 Then
              'This line is a string resource
              Dim str() As String = Split(MyLine, "=")
              ResKey = str(0).Trim()
              ResVal = str(1).Trim()

              'Add this info to the table
              ResData.Rows.Add(ResData.NewRow)
              ResData.Rows(ResData.Rows.Count - 1)(KeyCol) = ResKey
              ResData.Rows(ResData.Rows.Count - 1)(TextCol) = ResVal
              ResData.Rows(ResData.Rows.Count - 1)(CommentCol) = ResComment
            End If


          End If
        End If
      End While

    Catch ex As Exception
      Throw ex

    End Try

  End Sub
  Private Sub SaveToTextFile(ByVal ResData As DataTable)
    Dim fname As String
    Dim ResKey As String
    Dim ResVal As String
    Dim ResComment As String
    Dim ResRow As DataRow

    'Do not try anything if we are handed an invalid table
    'This is better than a try catch block.  Avoid errors when possible.  
    'Do not just catch them.
    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    'Split the filename and make it a text file
    Dim File_Info As New FileInfo(m_SaveFile)
    fname = File_Info.FullName + ".txt"

    Try
      'Open up the new text file stream
      Dim MyStream As New StreamWriter(fname)

      'Iterate over the rows in the table and add to the text resource file
      For Each ResRow In ResData.Rows
        ResKey = ResRow(KeyCol).ToString.PadRight(MaxKeyLen + 1)
        ResVal = ResRow(TextCol).ToString
        ResComment = ResRow(CommentCol).ToString
        If Len(ResComment) > 0 Then
          MyStream.WriteLine(";" + ResComment)
        End If
        MyStream.WriteLine(ResKey + " = " + ResVal)
        MyStream.WriteLine()
      Next

      MyStream.Flush()
      MyStream.Close()

    Catch ex As Exception
      Throw ex

    End Try

  End Sub
  Private Sub FillFromXMLFile(ByRef ResData As DataTable)

    'Do not try anything if we are handed an invalid table
    'This is better than a try catch block.  Avoid errors when possible.  
    'Do not just catch them.
    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    Try
      Dim ResXReader As New ResXResourceReader(m_ResFile)
      Dim En As IDictionaryEnumerator = ResXReader.GetEnumerator()

      'Iterate over the resource file
      'Add a row for each resource string and put key and value in correct 
      'columns Don't forget! ResX resource files can contain pictures.  
      'We only want the strings!
      While (En.MoveNext)
        If En.Value.GetType Is GetType(String) Then
          ResData.Rows.Add(ResData.NewRow)
          ResData.Rows(ResData.Rows.Count - 1)(KeyCol) = En.Key
          ResData.Rows(ResData.Rows.Count - 1)(TextCol) = En.Value

        ElseIf En.Value.GetType Is GetType(Bitmap) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        ElseIf En.Value.GetType Is GetType(Icon) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        ElseIf En.Value.GetType Is GetType(Image) Then
          Dim rImg As New ResImage(En.Key, En.Value)
          m_PicCol.Add(rImg, En.Key.ToString())
        End If
      End While


      ResXReader.Close()

    Catch ex As Exception
      Throw ex

    End Try

  End Sub
  Private Sub SaveToXMLFile(ByRef ResData As DataTable)
    Dim Fname As String
    Dim Pic As ResImage

    'Do not try anything if we are handed an invalid table
    'This is better than a try catch block.  Avoid errors when possible.  
    'Do not just catch them.
    If ResData Is Nothing Then
      Throw New InvalidTable("Data table was not defined")
      Exit Sub
    End If

    'Split the filename and make it a text file
    Dim File_Info As New FileInfo(m_SaveFile)
    Fname = File_Info.FullName + ".resx"

    Try
      'This will write over the exisiting file!!
      Dim ResxWriter As New ResXResourceWriter(Fname)
      Dim ResKey As String
      Dim ResVal As String
      Dim ResRow As DataRow


      'Iterate over the rows in the table and add to the resource file
      For Each ResRow In ResData.Rows
        ResKey = ResRow(KeyCol).ToString
        ResVal = ResRow(TextCol).ToString
        ResxWriter.AddResource(ResKey, ResVal)
      Next

      'Save the pictures
      For Each Pic In m_PicCol
        ResxWriter.AddResource(Pic.Name, Pic.Image)
      Next

      'Write out the resource file and close it.
      ResxWriter.Generate()
      ResxWriter.Close()

    Catch ex As Exception
      Throw ex

    End Try

  End Sub


End Class

'============================ NEW CLASS =======================
Public Class ResImage

  Private img As Image
  Private imgName As String
  Private imgType As String

  Public Sub New(ByVal Key As Object, ByVal Value As Object)
    'Value is an object becaus of the way it is passed in
    img = CType(Value, Image)
    imgName = Key.ToString
    imgType = Value.GetType.ToString

  End Sub
  Public Sub New(ByVal Key As String, ByVal Value As Object)
    'Value is an object becaus of the way it is passed in
    img = CType(Value, Image)
    imgName = Key
    imgType = Value.GetType.ToString

  End Sub

  Public Property Name() As String
    Get
      Return imgName
    End Get
    Set(ByVal Value As String)
      imgName = Value
    End Set
  End Property
  Public ReadOnly Property Image() As Image
    Get
      Return img
    End Get
  End Property
  Public ReadOnly Property Type() As String
    Get
      Return imgType
    End Get
  End Property

End Class
