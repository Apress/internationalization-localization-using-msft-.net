
Option Strict On


Module Consts

  Public Const KeyCol As String = "Key"
  Public Const TextCol As String = "Text"
  Public Const CommentCol As String = "Comment"
  Public Const MaxKeyLen As Integer = 15
  Public Const CommentChar As Char = ";"c

  Public Enum ResTypes
    TextType = 1
    XMLType = 2
    BinType = 3
  End Enum

End Module

