Imports System.Resources
Imports System.Collections

Module Module1

  Sub Main()

    'Open a resource reader and get an enumerator from it
    Dim reader = New ResourceReader("ch5RR.resources")
    Dim en As IDictionaryEnumerator = reader.GetEnumerator()

    Do While (en.MoveNext)
      Console.WriteLine("Name: {0} - Value: {1}", _
                  en.Key.ToString().PadRight(10, " "), _
                  en.Value)
    Loop
    reader.Close()

    'Loose resource example
    Dim rm As ResourceManager
    rm = ResourceManager.CreateFileBasedResourceManager("ch5rr", ".", Nothing)
    Console.WriteLine(rm.GetString("first"))

    Console.ReadLine()
  End Sub

End Module
