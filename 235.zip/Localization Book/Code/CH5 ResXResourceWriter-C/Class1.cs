using System;
using System.Resources;
using System.Drawing;
using System.Collections;

namespace CH5ResourceWriter_C
{
   /// <summary>
   /// ResXResourceWriter and reader example
   /// </summary>
   class Class1
   {
      static void Main(string[] args)
      {
         ResXResourceWriter RwX = new ResXResourceWriter("CH5RwX.resx");

         RwX.AddResource("key 1", "First value");
         RwX.AddResource("key 2", "Second value");
         RwX.AddResource("key 3", "Third value");

         // add an image to the resource file
         Image img = Image.FromFile("crane.jpg");
         RwX.AddResource("crane.jpg", img);

         RwX.Generate();
         RwX.Close();

         ResXResourceReader RrX = new ResXResourceReader("CH5RwX.resx");
         IDictionaryEnumerator RrEn = RrX.GetEnumerator();
         while (RrEn.MoveNext())
         {
            Console.WriteLine("Name: {0} - Value: {1}", 
               RrEn.Key.ToString().PadRight(10, ' '), 
               RrEn.Value);
         }
         RrX.Close();

         Console.ReadLine();
      }
   }
}
