  using System;
  using System.Collections;

  namespace CH8ResEdit_C
  {
    /// <summary>
    /// This is the collection class that handles a collection of 
    /// ResImage objects.  Traditionally a collection of objects is
    /// named that object with an 's' on the end.
    /// </summary>
    public class ResImages : IEnumerable
    {
      //Slower than Hash table but more flexible
      //Can get item by index number or by key.
      //Most like VB type collection
      private SortedList mCol;
      
      public ResImages()
		  {
        mCol = new  SortedList();
      }

      // enables foreach processing
      private mEnum GetEnumerator() 
      {
        return new mEnum(this);
      }

      //Property count
      public int Count
      {
        get { return mCol.Count; }
      }

      // ----- overloaded add method ------
      public void Add(ResImage w)
      {
          mCol.Add( w.Name, w);
      }
      public void Add(ResImage w, string key)
      {
        mCol.Add(key,w);
      }

      // ----- overloaded remove method ------
      public void Remove(int Index)
      {
        mCol.RemoveAt(Index);
      }
      public void Remove(string key)
      {
        mCol.Remove(key);
      }

      // ----- overloaded item method ------
      public ResImage Item(int index)
      {
        return (ResImage) mCol.GetByIndex(index);
      }
      public ResImage Item(string key)
      {
        return (ResImage) mCol[key];
      }

  // -------------- Below is where I implement the IEnumerator interface -------

      // Implement the GetEnumerator() method:
      IEnumerator IEnumerable.GetEnumerator() 
      {
          return GetEnumerator();
      }

      // Declare the enumerator and implement the IEnumerator interface:
      private class mEnum: IEnumerator 
      {
        private int nIndex;
        private ResImages collection;

        // constructor. make the collection
        public mEnum(ResImages coll) 
        {
          collection = coll;
          nIndex = -1;
        }

        // start over
        public void Reset() 
        {
          nIndex = -1;
        }

        // bump up the index
        public bool MoveNext() 
        {
          nIndex++;
          return(nIndex <  collection.mCol.Count);
        }

        // get the current object
        public ResImage Current 
        {
          get {return (ResImage) collection.mCol.GetByIndex(nIndex); }
        }

        // The current property on the IEnumerator interface:
        object IEnumerator.Current 
        {
          get { return(Current); }
        }
      }
    }
  }
