Imports System
Imports System.Resources

Module Module1

   Sub Main()
    Dim Rw As New ResourceWriter("CH5Rw.resources")
      Dim Rr As ResourceReader
      Dim RrEn As IDictionaryEnumerator

      Rw.AddResource("key 1", "First value")
      Rw.AddResource("key 2", "Second value")
      Rw.AddResource("key 3", "Third value")
      Rw.Generate()
      Rw.Close()

    Rr = New ResourceReader("CH5Rw.resources")
      RrEn = Rr.GetEnumerator
      Do While (RrEn.MoveNext)
         Console.WriteLine("Name: {0} - Value: {1}", _
                     RrEn.Key.ToString().PadRight(10, " "), _
                     RrEn.Value)
      Loop
      Rr.Close()

      Console.ReadLine()
   End Sub

End Module
