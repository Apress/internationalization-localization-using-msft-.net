using System;
using System.Collections;
using System.Globalization;
using System.Resources;
using System.IO;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text.RegularExpressions;


namespace CH7ResEdit_C
{
   /// <summary>
   /// Summary description for ResUtil.
   /// </summary>
   /// 

   public enum ResTypes
   {
      TextType = 1,
      XMLType = 2,
      BinType = 3
   }

   public class ResUtilConsts
   {
      public const string KeyCol = "Key";
      public const string TextCol = "Text";
      public const string CommentCol = "Comment";
      public const int MaxKeyLen = 15;
      public const char CommentChar = ';';
   }


  public class ResUtil
  {
  private string m_ResFile;
  private string m_SaveFile;
  private ResTypes m_ResType;
  private ResImages m_PicCol;



  public ResUtil()
  {
    //Default to binary file.  Default name
    m_ResType = ResTypes.BinType;
    m_ResFile = "BinResource.resources";
    m_SaveFile = m_ResFile;
    m_PicCol = new ResImages();
  }
  public ResUtil(string ResourceFilename)
  {
    m_ResType = ResTypes.BinType;
    m_ResFile = ResourceFilename;
    m_SaveFile = m_ResFile;
    m_PicCol = new ResImages();
  }
  public ResUtil(string ResourceFilename, ResTypes ResourceType)
  {
    m_ResType = ResourceType;
    m_ResFile = ResourceFilename;
    m_SaveFile = m_ResFile;
    m_PicCol = new ResImages();
  }

  public string FileName
  {
    get { return m_ResFile; }
    set { m_ResFile = value; }
  }

  public ResTypes ResourceType
  {
    get { return m_ResType; }
    set { m_ResType = value; }
  }
  public ResImages Pics
  {
    get { return m_PicCol; }
  }

  public string OutputFileName
  {
    get { return m_SaveFile; }
    set { m_SaveFile = value; }
  }

  public void GetData(DataTable ResData, bool append)
  {
    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }


    //Make sure that memory is clear
    if (!append )
    {
      ResData.Clear();
      while ( m_PicCol.Count > 0 )
          m_PicCol.Remove(1);
    }


    switch ( m_ResType )
    {
      case ResTypes.TextType:
        try
        {
          FillFromTextFile(ResData);
        }
        catch (Exception ex)
        {
          throw ex;
        }
        break;
      case ResTypes.XMLType:
        try
        {
          FillFromXMLFile(ResData);
        }
        catch (Exception ex)
        {
          throw ex;
        }
        break;
      case ResTypes.BinType:
        try
        {
          FillFromBinaryFile(ResData);
        }
        catch (Exception ex)
        {
          throw ex;
        }
        break;
    }
  }

  public void SaveData(DataTable ResData, ResImages Pics, ResTypes ResType)
  {
    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }

    m_PicCol = Pics;
    switch ( ResType )
    {
      case ResTypes.TextType:
          SaveToTextFile(ResData);
          break;
      case ResTypes.XMLType:
          SaveToXMLFile(ResData);
          break;
      case ResTypes.BinType:
          SaveToBinaryFile(ResData);
          break;
    }
  }

  private void FillFromBinaryFile(DataTable ResData)
  {
    //Do not try anything if we are handed an invalid table
    //This is better than a try catch block.  Avoid errors when possible.  
    //Do not just catch them.
    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }


    try
    {
      ResourceReader ResReader = new  ResourceReader(m_ResFile);
      IDictionaryEnumerator En = ResReader.GetEnumerator();

      //Iterate over the resource file
      //Add a row for each resource string and put key and value in 
      // correct columns Don't forget! ResX resource files can contain 
      //pictures.  We only want the strings!
      while (En.MoveNext())
      {

        if ( En.Value.GetType() == typeof(string))
        {
          ResData.Rows.Add(ResData.NewRow());
          ResData.Rows[ResData.Rows.Count - 1][ResUtilConsts.KeyCol] = En.Key;
          ResData.Rows[ResData.Rows.Count - 1][ResUtilConsts.TextCol] = En.Value;
        }
        else if (En.Value.GetType() == typeof(Bitmap))
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
        else if (En.Value.GetType() == typeof(Icon))
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
        else if ( En.Value.GetType() == typeof(Image) )
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
      }

      ResReader.Close();
    }
    catch (Exception ex)
    {
      throw ex;
    }
  }

  private void SaveToBinaryFile(DataTable ResData )
  {
    string Fname;

    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }

    //Split the filename and make it a text file
    FileInfo File_Info = new FileInfo(m_SaveFile);
    Fname = File_Info.FullName + ".resources";


    try
    {
      //This will write over the exisiting file!!
      ResourceWriter ResWriter = new ResourceWriter(Fname);
      string ResKey;
      string ResVal;

      //Iterate over the rows in the table and add to the resource file
      foreach ( DataRow ResRow in ResData.Rows )
      {
        ResKey = ResRow[ResUtilConsts.KeyCol].ToString();
        ResVal = ResRow[ResUtilConsts.TextCol].ToString();
        ResWriter.AddResource(ResKey, ResVal);
      }

      //Save the pictures
      foreach ( ResImage Pic in m_PicCol )
      {
        ResWriter.AddResource(Pic.Name, Pic.image);
      }

      //Write out the resource file and close it.
      ResWriter.Generate();
      ResWriter.Close();
    }
    catch (Exception ex)
    {
      throw ex;
    }
}

  private void FillFromTextFile(DataTable ResData )
  {
    string ResKey;
    string ResVal;
    string ResComment;
    //    Dim ResRow As DataRow

    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }

    try
    {
      StreamReader MyStream = new StreamReader(m_ResFile);
      string MyLine;

      //Any string with a comment marker is considered a comment.  
      //Resgen thinks so too.
      while (true)
      {
        if ((MyLine = MyStream.ReadLine()) == null )
          break;

        if (MyLine != "" )
        {
          // Instantiate a new Regular expression object
          Regex r = new Regex(";"); 
          // Find a single match in the string.
          Match m = r.Match(MyLine); 
          if (m.Index < 2 )   // >=2 is an Ambiguous line
          {
            ResComment = "";
            //This line is a comment so digest it as such
            if (m.Index == 1 )
              ResComment = MyLine.ToString(). 
                                  TrimStart(ResUtilConsts.CommentChar);

            if (m.Index == 0 )
            {
              //This line is a string resource
              string[] str = MyLine.Split('=');
              ResKey = str[0].Trim();
              ResVal = str[1].Trim();

              //Add this info to the table
              ResData.Rows.Add(ResData.NewRow());
              ResData.Rows[ResData.Rows.Count - 1]
                          [ResUtilConsts.KeyCol] = ResKey;
              ResData.Rows[ResData.Rows.Count - 1]
                          [ResUtilConsts.TextCol] = ResVal;
              ResData.Rows[ResData.Rows.Count - 1]
                          [ResUtilConsts.CommentCol] = ResComment;
            }
          }
        }
      }
    }

    catch (Exception ex)
    {
      throw ex;
    }

  }

  private void SaveToTextFile(DataTable ResData)
  {
    string fname;
    string ResKey;
    string ResVal;
    string ResComment;

    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }

    //Split the filename and make it a text file
    FileInfo File_Info = new FileInfo(m_SaveFile);
    fname = File_Info.FullName + ".txt";

    try
    {
      //Open up the new text file stream
      StreamWriter MyStream = new StreamWriter(fname);

      //Iterate over the rows in the table and add to the text resource file
      foreach ( DataRow ResRow in ResData.Rows )
      {
        ResKey = ResRow[ResUtilConsts.KeyCol].ToString().
                        PadRight(ResUtilConsts.MaxKeyLen + 1);
        ResVal = ResRow[ResUtilConsts.TextCol].ToString();
        ResComment = ResRow[ResUtilConsts.CommentCol].ToString();
        if (ResComment.Length > 0 )
          MyStream.WriteLine(";" + ResComment);

        MyStream.WriteLine(ResKey + " = " + ResVal);
        MyStream.WriteLine();
      }

      MyStream.Flush();
      MyStream.Close();
    }
    catch (Exception ex)
    {
      throw ex;
    }
  }

  private void FillFromXMLFile(DataTable ResData)
  {
    //Do not try anything if we are handed an invalid table
    //This is better than a try catch block.  Avoid errors when possible.  
    //Do not just catch them.
    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }


    try
    {
      ResXResourceReader ResXReader = new  ResXResourceReader(m_ResFile);
      IDictionaryEnumerator En = ResXReader.GetEnumerator();

      while (En.MoveNext())
      {
        if ( En.Value.GetType() == typeof(string))
        {
          ResData.Rows.Add(ResData.NewRow());
          ResData.Rows[ResData.Rows.Count - 1][ResUtilConsts.KeyCol] = En.Key;
          ResData.Rows[ResData.Rows.Count - 1][ResUtilConsts.TextCol] = En.Value;
        }
        else if (En.Value.GetType() == typeof(Bitmap))
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
        else if (En.Value.GetType() == typeof(Icon))
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
        else if ( En.Value.GetType() == typeof(Image) )
        {
          ResImage rImg = new ResImage(En.Key, En.Value);
          m_PicCol.Add(rImg, En.Key.ToString());
        }
      }

      ResXReader.Close();
    }
    catch (Exception ex)
    {
      throw ex;
    }
  }

  private void SaveToXMLFile(DataTable ResData)
  {
    string Fname;

    if ( ResData == null )
    {
      throw new InvalidTable("Data table was not defined");
      return;
    }

    //Split the filename and make it a resx file
    FileInfo File_Info = new FileInfo(m_SaveFile);
    Fname = File_Info.FullName + ".resx";


    try
    {
      //This will write over the exisiting file!!
      ResXResourceWriter ResxWriter = new ResXResourceWriter(Fname);
      string ResKey;
      string ResVal;

      //Iterate over the rows in the table and add to the resource file
      foreach ( DataRow ResRow in ResData.Rows )
      {
        ResKey = ResRow[ResUtilConsts.KeyCol].ToString();
        ResVal = ResRow[ResUtilConsts.TextCol].ToString();
        ResxWriter.AddResource(ResKey, ResVal);
      }

      //Save the pictures
      foreach ( ResImage Pic in m_PicCol )
      {
        ResxWriter.AddResource(Pic.Name, Pic.image);
      }

      //Write out the resource file and close it.
      ResxWriter.Generate();
      ResxWriter.Close();
    }
    catch (Exception ex)
    {
      throw ex;
    }
  }
  }



   //===================== A NEW CLASS =======================


   public class InvalidTable : System.Exception
   {
      public InvalidTable( string Message )
      {
        
      }
   }


   //===================== A NEW CLASS =======================

  public class ResImage
  {
    private Image img;
    private string imgName;
    private string imgType;


    public ResImage(object key, object val)
    {
      img = (Image)val;
      imgName = key.ToString();
      imgType = val.GetType().ToString();
    }

    public ResImage(string key, object val)
    {
      img = (Image)val;
      imgName = key;
      imgType = val.GetType().ToString();
    }

    public string Name
    {
      get { return imgName; }
      set { imgName = value; }
    }

    public Image image
    {
      get { return img; }
    }

    public string type
    {
      get { return imgType; }
    }

  }

  }
