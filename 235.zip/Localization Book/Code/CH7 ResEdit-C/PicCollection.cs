using System;

namespace CH7ResEdit_C
{
	/// <summary>
	/// Summary description for PicCollection.
	/// </summary>
	public class PicCollection
	{
		public PicCollection()
		{

      }
	}
}
