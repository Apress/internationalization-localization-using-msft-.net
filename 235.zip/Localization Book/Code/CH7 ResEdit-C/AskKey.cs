using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CH7ResEdit_C
{
	/// <summary>
	/// Summary description for AskKey.
	/// </summary>
	public class AskKey : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Button cmdOK;
      private System.Windows.Forms.Button cmdCancel;
      private System.Windows.Forms.TextBox txtKey;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.PictureBox KeyPic;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;


      public AskKey()
      {
         InitializeComponent();

         // Add event handlers
         this.cmdOK.Click += new System.EventHandler(this.OK);
         this.cmdCancel.Click += new System.EventHandler(this.Cancel);

      }
      public AskKey(ResImage ResImg)
      {
         InitializeComponent();
         m_ResImg = ResImg;

         // Add event handlers
         this.cmdOK.Click += new System.EventHandler(this.OK);
         this.cmdCancel.Click += new System.EventHandler(this.Cancel);

      }

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.KeyPic = new System.Windows.Forms.PictureBox();
         this.cmdCancel = new System.Windows.Forms.Button();
         this.label1 = new System.Windows.Forms.Label();
         this.txtKey = new System.Windows.Forms.TextBox();
         this.cmdOK = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // KeyPic
         // 
         this.KeyPic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.KeyPic.Location = new System.Drawing.Point(16, 64);
         this.KeyPic.Name = "KeyPic";
         this.KeyPic.Size = new System.Drawing.Size(80, 80);
         this.KeyPic.TabIndex = 4;
         this.KeyPic.TabStop = false;
         // 
         // cmdCancel
         // 
         this.cmdCancel.Location = new System.Drawing.Point(208, 104);
         this.cmdCancel.Name = "cmdCancel";
         this.cmdCancel.Size = new System.Drawing.Size(64, 32);
         this.cmdCancel.TabIndex = 1;
         this.cmdCancel.Text = "Cancel";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(16, 8);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(248, 23);
         this.label1.TabIndex = 5;
         this.label1.Text = "Picture Key";
         this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
         // 
         // txtKey
         // 
         this.txtKey.Location = new System.Drawing.Point(16, 32);
         this.txtKey.Name = "txtKey";
         this.txtKey.Size = new System.Drawing.Size(248, 20);
         this.txtKey.TabIndex = 3;
         this.txtKey.Text = "";
         // 
         // cmdOK
         // 
         this.cmdOK.Location = new System.Drawing.Point(120, 104);
         this.cmdOK.Name = "cmdOK";
         this.cmdOK.Size = new System.Drawing.Size(64, 32);
         this.cmdOK.TabIndex = 0;
         this.cmdOK.Text = "OK";
         // 
         // AskKey
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(290, 151);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.label1,
                                                                      this.KeyPic,
                                                                      this.txtKey,
                                                                      this.cmdCancel,
                                                                      this.cmdOK});
         this.Name = "AskKey";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "Assign key to picture";
         this.Load += new System.EventHandler(this.AskKey_Load);
         this.ResumeLayout(false);

      }
		#endregion


      private ResImage m_ResImg;

      private void AskKey_Load(object sender, System.EventArgs e)
      {
         if ( m_ResImg != null )
         {
            KeyPic.Image = m_ResImg.image;
            txtKey.Text = m_ResImg.Name;
            txtKey.SelectAll();
         }

      }
      private void OK(object sender, System.EventArgs e)
      {
         m_ResImg.Name = txtKey.Text.ToString();
         DialogResult = DialogResult.OK;
      }
      private void Cancel(object sender, System.EventArgs e)
      {
         DialogResult = DialogResult.Cancel;
      }
	}
}
