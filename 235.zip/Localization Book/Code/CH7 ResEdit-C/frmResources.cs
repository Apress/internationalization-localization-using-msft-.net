using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using MS = Microsoft.VisualBasic.Strings;

namespace CH7ResEdit_C
{
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class frmResources : System.Windows.Forms.Form
  {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.MenuItem menuItem1;
    internal System.Windows.Forms.StatusBar sbStatus;
    private System.Windows.Forms.StatusBarPanel spFile;
    private System.Windows.Forms.StatusBarPanel spStatus;
    private System.Windows.Forms.StatusBarPanel spDate;
    private System.Windows.Forms.Button cmdQuit;
    private System.Windows.Forms.DataGrid dgStrings;
    private System.Windows.Forms.Panel PicPanel;
    private System.Windows.Forms.Button cmdAddPic;
    private System.Windows.Forms.Button cmdDelPic;
    private System.Windows.Forms.ListBox lstPictures;
    private System.Windows.Forms.PictureBox pic;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ListBox lstCultures;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label lblTxtFname;
    private System.Windows.Forms.Label lblXMLfname;
    private System.Windows.Forms.Label lblBinFname;
    private System.Windows.Forms.TextBox txtBaseName;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

    // Programmer generated code!
    const int GridLineWidth=1; //Pixel width of a grid line
    const string ResourceTableName  = "Resources";

    const int TEXT_TAB = 0;
    const int GRAPHICS_TAB = 1;
    const int FINAL_TAB = 2;
    const int PICSPACE = 10;
    const int PICSIZE = 64;

    private DataTable m_StringTable;
    private String m_ResFile;
    private String m_NewFname;

    private System.Windows.Forms.MenuItem mnuAppend;
    private System.Windows.Forms.MenuItem mnuOpen;
    private System.Windows.Forms.MenuItem mnuExit;
    private System.Windows.Forms.OpenFileDialog OpenResFile;
    private ResTypes m_ResType;
    private System.Windows.Forms.TabControl tcResources;
    private System.Windows.Forms.CheckBox chkCreateBin;
    private System.Windows.Forms.Label lblInFilename;
    private System.Windows.Forms.Label lblResStringNum;
    private System.Windows.Forms.Label lblNumPics;
    private System.Windows.Forms.Button cmdSave;
    private System.Windows.Forms.CheckBox chkCreateXML;
    private System.Windows.Forms.CheckBox chkCreateText;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.Label label11;
    private ResImages m_Pictures = new ResImages();

	public frmResources()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

    //Set up the delegates for events here
    this.mnuExit.Click += 
              new System.EventHandler(this.ProgExit);
    this.mnuOpen.Click += 
              new System.EventHandler(this.GetResources);
    this.mnuAppend.Click += 
              new System.EventHandler(this.GetResources);
    this.lstPictures.SelectedIndexChanged += 
              new System.EventHandler(this.PicList);
    this.tcResources.Click += 
              new System.EventHandler(this.TabChange);
    this.cmdAddPic.Click += 
              new System.EventHandler(this.AddPic);
    this.cmdDelPic.Click += 
              new System.EventHandler(this.RemovePic);
    this.txtBaseName.TextChanged += 
              new System.EventHandler(this.NameChanged);
    this.lstCultures.SelectedIndexChanged += 
              new System.EventHandler(this.CulturePick);
    this.chkCreateBin.CheckStateChanged += 
              new System.EventHandler(this.Create_Checked);
    this.chkCreateText.CheckStateChanged += 
              new System.EventHandler(this.Create_Checked);
    this.chkCreateXML.CheckStateChanged += 
              new System.EventHandler(this.Create_Checked);
    this.cmdSave.Click += 
              new System.EventHandler(this.SaveIt);
  }

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
    this.mnuExit = new System.Windows.Forms.MenuItem();
    this.chkCreateBin = new System.Windows.Forms.CheckBox();
    this.mnuAppend = new System.Windows.Forms.MenuItem();
    this.cmdDelPic = new System.Windows.Forms.Button();
    this.mainMenu1 = new System.Windows.Forms.MainMenu();
    this.menuItem1 = new System.Windows.Forms.MenuItem();
    this.mnuOpen = new System.Windows.Forms.MenuItem();
    this.dgStrings = new System.Windows.Forms.DataGrid();
    this.PicPanel = new System.Windows.Forms.Panel();
    this.lblNumPics = new System.Windows.Forms.Label();
    this.tcResources = new System.Windows.Forms.TabControl();
    this.tabPage1 = new System.Windows.Forms.TabPage();
    this.tabPage2 = new System.Windows.Forms.TabPage();
    this.pic = new System.Windows.Forms.PictureBox();
    this.label10 = new System.Windows.Forms.Label();
    this.label11 = new System.Windows.Forms.Label();
    this.lstPictures = new System.Windows.Forms.ListBox();
    this.cmdAddPic = new System.Windows.Forms.Button();
    this.tabPage3 = new System.Windows.Forms.TabPage();
    this.groupBox2 = new System.Windows.Forms.GroupBox();
    this.cmdSave = new System.Windows.Forms.Button();
    this.txtBaseName = new System.Windows.Forms.TextBox();
    this.lblBinFname = new System.Windows.Forms.Label();
    this.lblXMLfname = new System.Windows.Forms.Label();
    this.chkCreateXML = new System.Windows.Forms.CheckBox();
    this.lblTxtFname = new System.Windows.Forms.Label();
    this.label8 = new System.Windows.Forms.Label();
    this.chkCreateText = new System.Windows.Forms.CheckBox();
    this.label1 = new System.Windows.Forms.Label();
    this.lstCultures = new System.Windows.Forms.ListBox();
    this.groupBox1 = new System.Windows.Forms.GroupBox();
    this.lblResStringNum = new System.Windows.Forms.Label();
    this.lblInFilename = new System.Windows.Forms.Label();
    this.label4 = new System.Windows.Forms.Label();
    this.label3 = new System.Windows.Forms.Label();
    this.label2 = new System.Windows.Forms.Label();
    this.spDate = new System.Windows.Forms.StatusBarPanel();
    this.sbStatus = new System.Windows.Forms.StatusBar();
    this.spFile = new System.Windows.Forms.StatusBarPanel();
    this.spStatus = new System.Windows.Forms.StatusBarPanel();
    this.cmdQuit = new System.Windows.Forms.Button();
    this.OpenResFile = new System.Windows.Forms.OpenFileDialog();
    ((System.ComponentModel.ISupportInitialize)(this.dgStrings)).BeginInit();
    this.tcResources.SuspendLayout();
    this.tabPage1.SuspendLayout();
    this.tabPage2.SuspendLayout();
    this.tabPage3.SuspendLayout();
    this.groupBox2.SuspendLayout();
    this.groupBox1.SuspendLayout();
    ((System.ComponentModel.ISupportInitialize)(this.spDate)).BeginInit();
    ((System.ComponentModel.ISupportInitialize)(this.spFile)).BeginInit();
    ((System.ComponentModel.ISupportInitialize)(this.spStatus)).BeginInit();
    this.SuspendLayout();
    // 
    // mnuExit
    // 
    this.mnuExit.Index = 2;
    this.mnuExit.Text = "Exit";
    // 
    // chkCreateBin
    // 
    this.chkCreateBin.Location = new System.Drawing.Point(16, 192);
    this.chkCreateBin.Name = "chkCreateBin";
    this.chkCreateBin.Size = new System.Drawing.Size(264, 16);
    this.chkCreateBin.TabIndex = 0;
    this.chkCreateBin.Text = "Create Binary Resource File";
    // 
    // mnuAppend
    // 
    this.mnuAppend.Index = 1;
    this.mnuAppend.Text = "Append";
    // 
    // cmdDelPic
    // 
    this.cmdDelPic.Location = new System.Drawing.Point(136, 272);
    this.cmdDelPic.Name = "cmdDelPic";
    this.cmdDelPic.TabIndex = 2;
    this.cmdDelPic.Text = "Remove";
    // 
    // mainMenu1
    // 
    this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.menuItem1});
    // 
    // menuItem1
    // 
    this.menuItem1.Index = 0;
    this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuOpen,
                                                                            this.mnuAppend,
                                                                            this.mnuExit});
    this.menuItem1.Text = "File";
    // 
    // mnuOpen
    // 
    this.mnuOpen.Index = 0;
    this.mnuOpen.Text = "Open";
    // 
    // dgStrings
    // 
    this.dgStrings.DataMember = "";
    this.dgStrings.Dock = System.Windows.Forms.DockStyle.Fill;
    this.dgStrings.Name = "dgStrings";
    this.dgStrings.Size = new System.Drawing.Size(768, 334);
    this.dgStrings.TabIndex = 0;
    // 
    // PicPanel
    // 
    this.PicPanel.AutoScroll = true;
    this.PicPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.PicPanel.Location = new System.Drawing.Point(336, 48);
    this.PicPanel.Name = "PicPanel";
    this.PicPanel.Size = new System.Drawing.Size(408, 210);
    this.PicPanel.TabIndex = 0;
    // 
    // lblNumPics
    // 
    this.lblNumPics.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblNumPics.Location = new System.Drawing.Point(216, 72);
    this.lblNumPics.Name = "lblNumPics";
    this.lblNumPics.Size = new System.Drawing.Size(48, 16);
    this.lblNumPics.TabIndex = 0;
    // 
    // tcResources
    // 
    this.tcResources.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.tabPage1,
                                                                            this.tabPage2,
                                                                            this.tabPage3});
    this.tcResources.Location = new System.Drawing.Point(16, 16);
    this.tcResources.Name = "tcResources";
    this.tcResources.SelectedIndex = 0;
    this.tcResources.Size = new System.Drawing.Size(776, 360);
    this.tcResources.TabIndex = 1;
    // 
    // tabPage1
    // 
    this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.dgStrings});
    this.tabPage1.Location = new System.Drawing.Point(4, 22);
    this.tabPage1.Name = "tabPage1";
    this.tabPage1.Size = new System.Drawing.Size(768, 334);
    this.tabPage1.TabIndex = 0;
    this.tabPage1.Text = "Text";
    // 
    // tabPage2
    // 
    this.tabPage2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.pic,
                                                                         this.label10,
                                                                         this.label11,
                                                                         this.lstPictures,
                                                                         this.cmdDelPic,
                                                                         this.cmdAddPic,
                                                                         this.PicPanel});
    this.tabPage2.Location = new System.Drawing.Point(4, 4);
    this.tabPage2.Name = "tabPage2";
    this.tabPage2.Size = new System.Drawing.Size(768, 352);
    this.tabPage2.TabIndex = 1;
    this.tabPage2.Text = "Pictures";
    // 
    // pic
    // 
    this.pic.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
    this.pic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.pic.Location = new System.Drawing.Point(216, 48);
    this.pic.Name = "pic";
    this.pic.Size = new System.Drawing.Size(124, 112);
    this.pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
    this.pic.TabIndex = 6;
    this.pic.TabStop = false;
    // 
    // label10
    // 
    this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.label10.Location = new System.Drawing.Point(32, 32);
    this.label10.Name = "label10";
    this.label10.Size = new System.Drawing.Size(176, 16);
    this.label10.TabIndex = 5;
    this.label10.Text = "Key";
    this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    // 
    // label11
    // 
    this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.label11.Location = new System.Drawing.Point(336, 32);
    this.label11.Name = "label11";
    this.label11.Size = new System.Drawing.Size(408, 16);
    this.label11.TabIndex = 4;
    this.label11.Text = "Pictures";
    this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    // 
    // lstPictures
    // 
    this.lstPictures.Location = new System.Drawing.Point(32, 48);
    this.lstPictures.Name = "lstPictures";
    this.lstPictures.Size = new System.Drawing.Size(176, 199);
    this.lstPictures.TabIndex = 3;
    // 
    // cmdAddPic
    // 
    this.cmdAddPic.Location = new System.Drawing.Point(32, 272);
    this.cmdAddPic.Name = "cmdAddPic";
    this.cmdAddPic.TabIndex = 1;
    this.cmdAddPic.Text = "Add";
    // 
    // tabPage3
    // 
    this.tabPage3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.groupBox2,
                                                                         this.label1,
                                                                         this.lstCultures,
                                                                         this.groupBox1});
    this.tabPage3.Location = new System.Drawing.Point(4, 4);
    this.tabPage3.Name = "tabPage3";
    this.tabPage3.Size = new System.Drawing.Size(768, 352);
    this.tabPage3.TabIndex = 2;
    this.tabPage3.Text = "Final...";
    // 
    // groupBox2
    // 
    this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.cmdSave,
                                                                          this.txtBaseName,
                                                                          this.lblBinFname,
                                                                          this.lblXMLfname,
                                                                          this.chkCreateBin,
                                                                          this.chkCreateXML,
                                                                          this.lblTxtFname,
                                                                          this.label8,
                                                                          this.chkCreateText});
    this.groupBox2.Location = new System.Drawing.Point(448, 16);
    this.groupBox2.Name = "groupBox2";
    this.groupBox2.Size = new System.Drawing.Size(296, 288);
    this.groupBox2.TabIndex = 3;
    this.groupBox2.TabStop = false;
    this.groupBox2.Text = "Build Output File(s)";
    // 
    // cmdSave
    // 
    this.cmdSave.Location = new System.Drawing.Point(208, 240);
    this.cmdSave.Name = "cmdSave";
    this.cmdSave.Size = new System.Drawing.Size(75, 32);
    this.cmdSave.TabIndex = 6;
    this.cmdSave.Text = "Save";
    // 
    // txtBaseName
    // 
    this.txtBaseName.Location = new System.Drawing.Point(32, 48);
    this.txtBaseName.Name = "txtBaseName";
    this.txtBaseName.Size = new System.Drawing.Size(208, 20);
    this.txtBaseName.TabIndex = 5;
    this.txtBaseName.Text = "";
    // 
    // lblBinFname
    // 
    this.lblBinFname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblBinFname.Location = new System.Drawing.Point(16, 208);
    this.lblBinFname.Name = "lblBinFname";
    this.lblBinFname.Size = new System.Drawing.Size(264, 16);
    this.lblBinFname.TabIndex = 4;
    // 
    // lblXMLfname
    // 
    this.lblXMLfname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblXMLfname.Location = new System.Drawing.Point(16, 160);
    this.lblXMLfname.Name = "lblXMLfname";
    this.lblXMLfname.Size = new System.Drawing.Size(264, 16);
    this.lblXMLfname.TabIndex = 4;
    // 
    // chkCreateXML
    // 
    this.chkCreateXML.Location = new System.Drawing.Point(16, 144);
    this.chkCreateXML.Name = "chkCreateXML";
    this.chkCreateXML.Size = new System.Drawing.Size(264, 16);
    this.chkCreateXML.TabIndex = 0;
    this.chkCreateXML.Text = "Create XML Resource File";
    // 
    // lblTxtFname
    // 
    this.lblTxtFname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblTxtFname.Location = new System.Drawing.Point(16, 120);
    this.lblTxtFname.Name = "lblTxtFname";
    this.lblTxtFname.Size = new System.Drawing.Size(264, 16);
    this.lblTxtFname.TabIndex = 4;
    // 
    // label8
    // 
    this.label8.Location = new System.Drawing.Point(32, 32);
    this.label8.Name = "label8";
    this.label8.Size = new System.Drawing.Size(208, 16);
    this.label8.TabIndex = 3;
    this.label8.Text = "Base Name";
    // 
    // chkCreateText
    // 
    this.chkCreateText.Location = new System.Drawing.Point(16, 104);
    this.chkCreateText.Name = "chkCreateText";
    this.chkCreateText.Size = new System.Drawing.Size(264, 16);
    this.chkCreateText.TabIndex = 0;
    this.chkCreateText.Text = "Create Text file for translator";
    // 
    // label1
    // 
    this.label1.Location = new System.Drawing.Point(16, 128);
    this.label1.Name = "label1";
    this.label1.Size = new System.Drawing.Size(408, 16);
    this.label1.TabIndex = 2;
    this.label1.Text = "Choose Culture";
    this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    // 
    // lstCultures
    // 
    this.lstCultures.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.lstCultures.ItemHeight = 14;
    this.lstCultures.Location = new System.Drawing.Point(16, 144);
    this.lstCultures.Name = "lstCultures";
    this.lstCultures.Size = new System.Drawing.Size(408, 158);
    this.lstCultures.TabIndex = 1;
    // 
    // groupBox1
    // 
    this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.lblNumPics,
                                                                          this.lblResStringNum,
                                                                          this.lblInFilename,
                                                                          this.label4,
                                                                          this.label3,
                                                                          this.label2});
    this.groupBox1.Location = new System.Drawing.Point(16, 16);
    this.groupBox1.Name = "groupBox1";
    this.groupBox1.Size = new System.Drawing.Size(408, 100);
    this.groupBox1.TabIndex = 0;
    this.groupBox1.TabStop = false;
    this.groupBox1.Text = "Basics";
    // 
    // lblResStringNum
    // 
    this.lblResStringNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblResStringNum.Location = new System.Drawing.Point(16, 72);
    this.lblResStringNum.Name = "lblResStringNum";
    this.lblResStringNum.Size = new System.Drawing.Size(48, 16);
    this.lblResStringNum.TabIndex = 0;
    // 
    // lblInFilename
    // 
    this.lblInFilename.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
    this.lblInFilename.Location = new System.Drawing.Point(16, 32);
    this.lblInFilename.Name = "lblInFilename";
    this.lblInFilename.Size = new System.Drawing.Size(376, 16);
    this.lblInFilename.TabIndex = 0;
    // 
    // label4
    // 
    this.label4.Location = new System.Drawing.Point(216, 56);
    this.label4.Name = "label4";
    this.label4.Size = new System.Drawing.Size(176, 16);
    this.label4.TabIndex = 0;
    this.label4.Text = "Picture Count";
    // 
    // label3
    // 
    this.label3.Location = new System.Drawing.Point(16, 56);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(176, 16);
    this.label3.TabIndex = 0;
    this.label3.Text = "String Count";
    // 
    // label2
    // 
    this.label2.Location = new System.Drawing.Point(16, 16);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(376, 16);
    this.label2.TabIndex = 0;
    this.label2.Text = "Input Filename";
    // 
    // spDate
    // 
    this.spDate.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
    this.spDate.Text = "Date:";
    // 
    // sbStatus
    // 
    this.sbStatus.Location = new System.Drawing.Point(0, 437);
    this.sbStatus.Name = "sbStatus";
    this.sbStatus.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                              this.spFile,
                                                                              this.spStatus,
                                                                              this.spDate});
    this.sbStatus.ShowPanels = true;
    this.sbStatus.Size = new System.Drawing.Size(816, 20);
    this.sbStatus.TabIndex = 3;
    this.sbStatus.Text = "statusBar1";
    // 
    // spFile
    // 
    this.spFile.Text = "File:";
    this.spFile.Width = 500;
    // 
    // spStatus
    // 
    this.spStatus.Text = "Status";
    this.spStatus.Width = 200;
    // 
    // cmdQuit
    // 
    this.cmdQuit.Location = new System.Drawing.Point(720, 384);
    this.cmdQuit.Name = "cmdQuit";
    this.cmdQuit.Size = new System.Drawing.Size(75, 32);
    this.cmdQuit.TabIndex = 2;
    this.cmdQuit.Text = "Quit";
    this.cmdQuit.Click += new System.EventHandler(this.ProgExit);
    // 
    // frmResources
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
    this.ClientSize = new System.Drawing.Size(816, 457);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this.sbStatus,
                                                                this.cmdQuit,
                                                                this.tcResources});
    this.Menu = this.mainMenu1;
    this.Name = "frmResources";
    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
    this.Text = "Resource Editor";
    this.Load += new System.EventHandler(this.Form1_Load);
    ((System.ComponentModel.ISupportInitialize)(this.dgStrings)).EndInit();
    this.tcResources.ResumeLayout(false);
    this.tabPage1.ResumeLayout(false);
    this.tabPage2.ResumeLayout(false);
    this.tabPage3.ResumeLayout(false);
    this.groupBox2.ResumeLayout(false);
    this.groupBox1.ResumeLayout(false);
    ((System.ComponentModel.ISupportInitialize)(this.spDate)).EndInit();
    ((System.ComponentModel.ISupportInitialize)(this.spFile)).EndInit();
    ((System.ComponentModel.ISupportInitialize)(this.spStatus)).EndInit();
    this.ResumeLayout(false);

  }
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new frmResources());
	}

    private void Form1_Load(object sender, System.EventArgs e)
    {
      InitStrings();
      SetupStringTable();
      dgStrings.DataSource = m_StringTable;
      SetupStringResourceGrid();
      AlignColumns();
    }

    private void InitStrings()
    {
      sbStatus.Panels[2].Text = DateTime.Now.ToString();
      sbStatus.Panels[1].Width = 100;
    }

    private void SetupStringTable()
    {
      //Give this table a name so I can synchronize to it with the grid
      m_StringTable = new DataTable(ResourceTableName);

      //Add three columns to the table
      m_StringTable.Columns.Add(new DataColumn(ResUtilConsts.KeyCol, 
                                Type.GetType("System.String")));
      m_StringTable.Columns.Add(new DataColumn(ResUtilConsts.TextCol, 
                                Type.GetType("System.String")));
      m_StringTable.Columns.Add(new DataColumn(ResUtilConsts.CommentCol, 
                                Type.GetType("System.String")));
    }

    private void SetupStringResourceGrid()
    {
      DataGridTableStyle dgS = new DataGridTableStyle();
      DataGridTextBoxColumn dgCKey;
      DataGridTextBoxColumn dgCText;
      DataGridTextBoxColumn dgCComment;


      //Set up a table style first then add it to the grid
      dgS.MappingName = ResourceTableName;
      dgS.PreferredColumnWidth = 300;
      dgS.SelectionBackColor = Color.Beige;
      dgS.SelectionForeColor = Color.Black;
      dgS.AllowSorting = true;

      //Make a column style for the first column and add it to the columnstyle
      dgCKey = new DataGridTextBoxColumn();
      dgCKey.MappingName = ResUtilConsts.KeyCol;
      dgCKey.HeaderText = "Resource Key";
      dgCKey.Width = 100;
      dgS.GridColumnStyles.Add(dgCKey);

      //Make a column style for the second column and add it to the columnstyle
      dgCComment = new DataGridTextBoxColumn();
      dgCComment.MappingName = ResUtilConsts.TextCol;
      dgCComment.HeaderText = "Resource Text";
      dgCComment.Width = 300;
      dgS.GridColumnStyles.Add(dgCComment);

      //Make a column style for the third column and add it to the columnstyle
      dgCText = new DataGridTextBoxColumn();
      dgCText.MappingName = ResUtilConsts.CommentCol;
      dgCText.HeaderText = "Comment";
      dgCText.Width = 400;
      dgS.GridColumnStyles.Add(dgCText);

      //First purge all table styles from this grid then add the one that I want
      dgStrings.TableStyles.Clear();
      dgStrings.TableStyles.Add(dgS);
    }

    private void AlignColumns()
    {
      dgStrings.TableStyles[0].GridColumnStyles[0].Width = 100;
      dgStrings.TableStyles[0].GridColumnStyles[1].Width = 300;
      dgStrings.TableStyles[0].GridColumnStyles[2].Width = 
        dgStrings.Size.Width - dgStrings.TableStyles[0].GridColumnStyles[0].Width
        - dgStrings.TableStyles[0].GridColumnStyles[1].Width
        - dgStrings.RowHeaderWidth - 4 * GridLineWidth;
    }

    private void FillPicList()
    {
      PicPanel.AutoScroll = true;
      pic.Image = null;
      foreach(ResImage ResImg in m_Pictures)
      {
        lstPictures.Items.Add(ResImg.Name);
        //Make a new picture box and add it to the 
        //panels control array
        AddPic2Panel(ResImg);
      }
      ArrangePictures();

      if (lstPictures.Items.Count > 0 )
      {
        lstPictures.SetSelected(0, true);
        cmdDelPic.Enabled = true;
      }
      else
        cmdDelPic.Enabled = false;
    }

    private void AddPic2Panel(ResImage ResImg)
    {
      PictureBox Pic;

      Pic = new PictureBox();
      Pic.Size = new Size(PICSIZE, PICSIZE);
      Pic.Location = new Point(10, 10);
      Pic.SizeMode = PictureBoxSizeMode.StretchImage;
      Pic.Image = ResImg.image;
      Pic.Tag = ResImg.Name;
      PicPanel.Controls.Add(Pic);
    }
    private void ArrangePictures()
    {
      int x;
      int y = 0;

      //Number of pictures in a row.
      //DO not show a picture if it means we get a horizontal
      //scroll bar
      int NumPicsInWidth  = (int)((PicPanel.Size.Width - PICSPACE) / 
                                  (PICSIZE + PICSPACE)) - 1;
      //Control collections are zero based.
      //VB type collections are 1 based.
      for (int k = 0; k<= PicPanel.Controls.Count - 1; k++)
      {
        //determine if we are in a new row
        if (k % (NumPicsInWidth) == 0 )
            x = PICSPACE;
        else
            x = PicPanel.Controls[k - 1].Location.X + PICSIZE + PICSPACE;

        if (k < NumPicsInWidth )
            y = PICSPACE;
        else if (k % (NumPicsInWidth) == 0 )
            y = PicPanel.Controls[k - 1].Location.Y + PICSIZE + PICSPACE;

        PicPanel.Controls[k].Location = new Point(x, y);
      }
    }

    public void BuildCompleteName()
    {
      m_NewFname = txtBaseName.Text == ""? "?": txtBaseName.Text;


      if ( lstCultures.SelectedItem !=null )
      {
        if (lstCultures.SelectedItem.ToString().Trim() != "(None)" )
          m_NewFname += "." + MS.Left(lstCultures.SelectedItem.ToString(),15)
                                      .Trim();

      }

      if (chkCreateText.Checked == true )
        lblTxtFname.Text = m_NewFname + ".txt";
      else
        lblTxtFname.Text = "";

      if (chkCreateXML.Checked == true )
        lblXMLfname.Text = m_NewFname + ".resx";
      else
        lblXMLfname.Text = "";

      if (chkCreateBin.Checked == true )
        lblBinFname.Text = m_NewFname + ".resources";
      else
        lblBinFname.Text = "";
    }

    private void NameChanged(object sender, System.EventArgs e)
    {
      BuildCompleteName();
    }
    private void CulturePick(object sender, System.EventArgs e)
    {
      BuildCompleteName();
    }
    private void Create_Checked(object sender, System.EventArgs e)
    {
      if( chkCreateBin.Checked == false && chkCreateXML.Checked == false && 
          chkCreateText.Checked == false )
        cmdSave.Enabled = false;
      else
        cmdSave.Enabled = true;

      BuildCompleteName();
    }
    private void SaveIt(object sender, System.EventArgs e)
    {
      ResUtil Res = new ResUtil(m_ResFile);
      Res.OutputFileName = m_NewFname;

      if (chkCreateText.Checked )
        Res.SaveData(m_StringTable, m_Pictures, ResTypes.TextType);

      if (chkCreateXML.Checked )
        Res.SaveData(m_StringTable, m_Pictures, ResTypes.XMLType);

      if (chkCreateBin.Checked )
        Res.SaveData(m_StringTable, m_Pictures, ResTypes.BinType);
    }
    private void PicList(object sender, System.EventArgs e)
    {
      ResImage rImg;

      rImg = (ResImage) m_Pictures.Item(lstPictures.SelectedItem.ToString());
      pic.Image = rImg.image;

      //Highlight the picture in question by
      //giving it a border.  Don't foget to "unborder" the others.
      foreach(PictureBox pb in PicPanel.Controls)
      {
        if (pb.Tag.ToString() == rImg.Name )
          pb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        else
          pb.BorderStyle = System.Windows.Forms.BorderStyle.None;
      }
    }
    private void GetResources(object sender, System.EventArgs e)
    {
      OpenResFile.Reset();
      OpenResFile.InitialDirectory = Directory.GetCurrentDirectory();
      OpenResFile.RestoreDirectory = true;
      OpenResFile.Filter = "Text files (*.txt)|*.txt|XML files " +
                           "(*.resx)|*.resx|Binary files (*.resources)|" +
                           "*.resources";

      if (OpenResFile.ShowDialog() == DialogResult.OK) 
      {
        m_ResType = (ResTypes) OpenResFile.FilterIndex;
        m_ResFile = OpenResFile.FileName;
        ResUtil Res = new ResUtil(m_ResFile, m_ResType);

        //clear the pictures
        lstPictures.Items.Clear();
        //In Beta 2 the clear function for the listbox does bot work correctly
        //So do it the hard way
        while (lstPictures.Items.Count > 0)
          lstPictures.Items.Remove(1);

        PicPanel.Controls.Clear();

        //Fill the string text box
        sbStatus.Panels[0].Text = m_ResFile;
        if (sender == mnuOpen )
        {
          Res.GetData(m_StringTable, false);
          m_Pictures = Res.Pics;
        }
        else if (sender == mnuAppend )
        {
          Res.GetData(m_StringTable, true);
          //Add to the pictures collection
          ResImages NewPics;

          NewPics = Res.Pics;
          foreach(ResImage p in NewPics)
            m_Pictures.Add(p);
        }
        FillPicList();
      }
    }

    private void TabChange(object sender, System.EventArgs e)
    {
      if (tcResources.SelectedIndex == FINAL_TAB )
      {
        lblInFilename.Text = m_ResFile;
        lblResStringNum.Text = m_StringTable.Rows.Count.ToString();
        lblNumPics.Text = m_Pictures.Count.ToString();

        CultureInfo[] AllCultures;
        AllCultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
        lstCultures.Items.Clear();
        lstCultures.Items.Add(" ".PadRight(10) + "(None)");
        lstCultures.Sorted = true;
        foreach(CultureInfo ACulture in AllCultures)
            lstCultures.Items.Add(ACulture.Name.PadRight(15) + 
                                  ACulture.DisplayName);

        chkCreateBin.Checked = true;
      }
      if (tcResources.SelectedIndex == GRAPHICS_TAB )
      {
        if( lstPictures.Items.Count < 1 )
          cmdDelPic.Enabled = false;
      }
    }

    private void AddPic(object sender, System.EventArgs e)
    {
      OpenResFile.Reset();
      OpenResFile.InitialDirectory = Directory.GetCurrentDirectory();
      OpenResFile.RestoreDirectory = true;
      OpenResFile.Filter =  "Picture files (*.jpg; *.bmp; *.gif)|" +
                            "*.jpg; *.bmp; *.gif";

      if (OpenResFile.ShowDialog() == DialogResult.OK) 
      {

        FileInfo fInfo = new FileInfo(OpenResFile.FileName);
        if ((fInfo.Extension.ToUpper() == ".JPG") || 
            (fInfo.Extension.ToUpper() == ".BMP") || 
            (fInfo.Extension.ToUpper() == ".GIF") )
        {
          //Add the picture to the collection
          ResImage rImg = new ResImage(OpenResFile.FileName, 
                                        Image.FromFile(OpenResFile.FileName));
          AskKey Keyform = new AskKey(rImg);
          if (Keyform.ShowDialog(this) == DialogResult.OK )
          {
            m_Pictures.Add(rImg, rImg.Name);
            //Add the picture to the panel and arrange
            AddPic2Panel(rImg);
            ArrangePictures();
            //Add the picture to the list and enable delete and select it
            lstPictures.Items.Add(rImg.Name);
            lstPictures.SetSelected(lstPictures.Items.Count - 1, true);
            cmdDelPic.Enabled = true;
          }
          Keyform.Dispose();
        }
      }
    }
    private void ProgExit(object sender, System.EventArgs e)
    {
      this.Dispose();
    }

    private void RemovePic(object sender, System.EventArgs e)
    {
      //Remove the picture from the picture collection
      m_Pictures.Remove(lstPictures.SelectedItem.ToString());

      //Remove the picture from the panel and rearrange the rest
      foreach( PictureBox pb in PicPanel.Controls)
      {
        if (pb.BorderStyle == System.Windows.Forms.BorderStyle.FixedSingle )
        {
          PicPanel.Controls.Remove(pb);
          ArrangePictures();
          break;
        }
      }

      //Remove the name from the listbox of keys and 
      //reselect the first one
      lstPictures.Items.Remove(lstPictures.SelectedItem);
      if (lstPictures.Items.Count > 0 )
        lstPictures.SetSelected(0, true);
      else
      {
        cmdDelPic.Enabled = false;
        pic.Image = null;
      }
    }
  }
}
