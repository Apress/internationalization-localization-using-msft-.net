using System;
using System.Globalization;
using System.Threading;

namespace Ch4CurrentInfo
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
         //CurrentInfo example
         CultureInfo MyCulture = new CultureInfo("es-ES");
         DateTimeFormatInfo Myfmt;
         DateTimeFormatInfo fmt1;

         Myfmt = MyCulture.DateTimeFormat;
         fmt1  = DateTimeFormatInfo.CurrentInfo;

         Console.WriteLine(Myfmt.GetMonthName(12));
         Console.WriteLine(fmt1.GetMonthName(12));
         Console.WriteLine(Thread.CurrentThread.
                           CurrentCulture.
                           DateTimeFormat.
                           GetMonthName(12));
         

      Console.ReadLine();
      }
	}
}
