Option Strict On

Imports System.Drawing.Image

Public Class AskKey
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  Public Sub New(ByVal ResImg As ResImage)

    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    m_ResImg = ResImg

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents lblKey As System.Windows.Forms.Label
  Friend WithEvents txtKey As System.Windows.Forms.TextBox
  Friend WithEvents cmdOK As System.Windows.Forms.Button
  Friend WithEvents KeyPic As System.Windows.Forms.PictureBox
  Friend WithEvents cmdCancel As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.txtKey = New System.Windows.Forms.TextBox()
    Me.cmdCancel = New System.Windows.Forms.Button()
    Me.cmdOK = New System.Windows.Forms.Button()
    Me.KeyPic = New System.Windows.Forms.PictureBox()
    Me.lblKey = New System.Windows.Forms.Label()
    Me.SuspendLayout()
    '
    'txtKey
    '
    Me.txtKey.Location = New System.Drawing.Point(16, 32)
    Me.txtKey.Name = "txtKey"
    Me.txtKey.Size = New System.Drawing.Size(248, 20)
    Me.txtKey.TabIndex = 1
    Me.txtKey.Text = ""
    '
    'cmdCancel
    '
    Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.cmdCancel.Location = New System.Drawing.Point(200, 104)
    Me.cmdCancel.Name = "cmdCancel"
    Me.cmdCancel.Size = New System.Drawing.Size(64, 32)
    Me.cmdCancel.TabIndex = 4
    Me.cmdCancel.Text = "Cancel"
    '
    'cmdOK
    '
    Me.cmdOK.Location = New System.Drawing.Point(120, 104)
    Me.cmdOK.Name = "cmdOK"
    Me.cmdOK.Size = New System.Drawing.Size(64, 32)
    Me.cmdOK.TabIndex = 2
    Me.cmdOK.Text = "OK"
    '
    'KeyPic
    '
    Me.KeyPic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.KeyPic.Location = New System.Drawing.Point(16, 64)
    Me.KeyPic.Name = "KeyPic"
    Me.KeyPic.Size = New System.Drawing.Size(76, 76)
    Me.KeyPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.KeyPic.TabIndex = 3
    Me.KeyPic.TabStop = False
    '
    'lblKey
    '
    Me.lblKey.Location = New System.Drawing.Point(16, 8)
    Me.lblKey.Name = "lblKey"
    Me.lblKey.Size = New System.Drawing.Size(248, 23)
    Me.lblKey.TabIndex = 0
    Me.lblKey.Text = "Picture Key"
    Me.lblKey.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'AskKey
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.CancelButton = Me.cmdCancel
    Me.ClientSize = New System.Drawing.Size(290, 151)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdCancel, Me.KeyPic, Me.cmdOK, Me.txtKey, Me.lblKey})
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Name = "AskKey"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Assign key to picture"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private m_ResImg As ResImage

  Private Sub AskKey_Load(ByVal sender As System.Object, _
                          ByVal e As System.EventArgs) Handles MyBase.Load

    If Not m_ResImg Is Nothing Then
      KeyPic.Image = m_ResImg.Image
      txtKey.Text = m_ResImg.Name
      txtKey.SelectAll()
    End If

  End Sub

  Private Sub cmdOK_Click(ByVal sender As System.Object, _
                          ByVal e As System.EventArgs) Handles cmdOK.Click

    m_ResImg.Name = txtKey.Text
    DialogResult = DialogResult.OK

  End Sub

  Private Sub cmdCancel_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs) Handles cmdCancel.Click

    DialogResult = DialogResult.Cancel

  End Sub
End Class
