Option Strict On

Imports System
Imports System.Globalization
Imports System.Resources
Imports System.Threading
Imports System.IO
Imports System.Drawing
Imports MS = Microsoft.visualbasic.Strings


Public Class frmResEdit
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    '  Thread.CurrentThread.CurrentCulture = New CultureInfo("de-DE")

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents cmdQuit As System.Windows.Forms.Button
  Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
  Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
  Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
  Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
  Friend WithEvents spFile As System.Windows.Forms.StatusBarPanel
  Friend WithEvents spDate As System.Windows.Forms.StatusBarPanel
  Friend WithEvents spStatus As System.Windows.Forms.StatusBarPanel
    Friend WithEvents dgStrings As System.Windows.Forms.DataGrid
  Friend WithEvents dgStringsStyle As System.Windows.Forms.DataGridTableStyle
  Friend WithEvents tcResource As System.Windows.Forms.TabControl
  Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
  Friend WithEvents mnuOpen As System.Windows.Forms.MenuItem
  Friend WithEvents OpenResFile As System.Windows.Forms.OpenFileDialog
  Friend WithEvents cmdDelPic As System.Windows.Forms.Button
  Friend WithEvents cmdAddPic As System.Windows.Forms.Button
  Friend WithEvents sbStatus As System.Windows.Forms.StatusBar
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents lstPictures As System.Windows.Forms.ListBox
  Friend WithEvents pic As System.Windows.Forms.PictureBox
  Friend WithEvents PicPanel As System.Windows.Forms.Panel
  Friend WithEvents lblPicKey As System.Windows.Forms.Label
  Friend WithEvents lblPictures As System.Windows.Forms.Label
  Friend WithEvents lstCultures As System.Windows.Forms.ListBox
    Friend WithEvents lblBinFname As System.Windows.Forms.Label
  Friend WithEvents lblTxtFname As System.Windows.Forms.Label
  Friend WithEvents lblXMLfname As System.Windows.Forms.Label
  Friend WithEvents chkCreateText As System.Windows.Forms.CheckBox
  Friend WithEvents chkCreateXML As System.Windows.Forms.CheckBox
  Friend WithEvents chkCreateBin As System.Windows.Forms.CheckBox
      Friend WithEvents lblInFilename As System.Windows.Forms.Label
    Friend WithEvents lblResStringNum As System.Windows.Forms.Label
    Friend WithEvents lblNumPics As System.Windows.Forms.Label
  Friend WithEvents txtBaseName As System.Windows.Forms.TextBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
  Friend WithEvents mnuAppend As System.Windows.Forms.MenuItem
  Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
  Friend WithEvents fraBasics As System.Windows.Forms.GroupBox
  Friend WithEvents lblPicCnt As System.Windows.Forms.Label
  Friend WithEvents lblStrCnt As System.Windows.Forms.Label
  Friend WithEvents lblInputFname As System.Windows.Forms.Label
  Friend WithEvents fraOutput As System.Windows.Forms.GroupBox
  Friend WithEvents lblBaseName As System.Windows.Forms.Label
  Friend WithEvents lblCulture As System.Windows.Forms.Label

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.lblPicCnt = New System.Windows.Forms.Label()
    Me.lblBaseName = New System.Windows.Forms.Label()
    Me.chkCreateXML = New System.Windows.Forms.CheckBox()
    Me.lblPictures = New System.Windows.Forms.Label()
    Me.lblTxtFname = New System.Windows.Forms.Label()
    Me.OpenResFile = New System.Windows.Forms.OpenFileDialog()
    Me.lblCulture = New System.Windows.Forms.Label()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.cmdQuit = New System.Windows.Forms.Button()
    Me.dgStringsStyle = New System.Windows.Forms.DataGridTableStyle()
    Me.dgStrings = New System.Windows.Forms.DataGrid()
    Me.pic = New System.Windows.Forms.PictureBox()
    Me.sbStatus = New System.Windows.Forms.StatusBar()
    Me.spFile = New System.Windows.Forms.StatusBarPanel()
    Me.spStatus = New System.Windows.Forms.StatusBarPanel()
    Me.spDate = New System.Windows.Forms.StatusBarPanel()
    Me.tcResource = New System.Windows.Forms.TabControl()
    Me.TabPage1 = New System.Windows.Forms.TabPage()
    Me.TabPage2 = New System.Windows.Forms.TabPage()
    Me.PicPanel = New System.Windows.Forms.Panel()
    Me.lblPicKey = New System.Windows.Forms.Label()
    Me.lstPictures = New System.Windows.Forms.ListBox()
    Me.cmdDelPic = New System.Windows.Forms.Button()
    Me.cmdAddPic = New System.Windows.Forms.Button()
    Me.TabPage3 = New System.Windows.Forms.TabPage()
    Me.fraBasics = New System.Windows.Forms.GroupBox()
    Me.lblNumPics = New System.Windows.Forms.Label()
    Me.lblStrCnt = New System.Windows.Forms.Label()
    Me.lblResStringNum = New System.Windows.Forms.Label()
    Me.lblInFilename = New System.Windows.Forms.Label()
    Me.lblInputFname = New System.Windows.Forms.Label()
    Me.fraOutput = New System.Windows.Forms.GroupBox()
    Me.cmdSave = New System.Windows.Forms.Button()
    Me.txtBaseName = New System.Windows.Forms.TextBox()
    Me.chkCreateBin = New System.Windows.Forms.CheckBox()
    Me.chkCreateText = New System.Windows.Forms.CheckBox()
    Me.lblBinFname = New System.Windows.Forms.Label()
    Me.lblXMLfname = New System.Windows.Forms.Label()
    Me.lstCultures = New System.Windows.Forms.ListBox()
    Me.mnuFile = New System.Windows.Forms.MenuItem()
    Me.mnuOpen = New System.Windows.Forms.MenuItem()
    Me.mnuAppend = New System.Windows.Forms.MenuItem()
    Me.mnuExit = New System.Windows.Forms.MenuItem()
    Me.MainMenu1 = New System.Windows.Forms.MainMenu()
    CType(Me.dgStrings, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.spFile, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.spStatus, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.spDate, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.tcResource.SuspendLayout()
    Me.TabPage1.SuspendLayout()
    Me.TabPage2.SuspendLayout()
    Me.TabPage3.SuspendLayout()
    Me.fraBasics.SuspendLayout()
    Me.fraOutput.SuspendLayout()
    Me.SuspendLayout()
    '
    'lblPicCnt
    '
    Me.lblPicCnt.Location = New System.Drawing.Point(216, 56)
    Me.lblPicCnt.Name = "lblPicCnt"
    Me.lblPicCnt.Size = New System.Drawing.Size(176, 16)
    Me.lblPicCnt.TabIndex = 0
    Me.lblPicCnt.Text = "Picture Count"
    '
    'lblBaseName
    '
    Me.lblBaseName.Location = New System.Drawing.Point(32, 32)
    Me.lblBaseName.Name = "lblBaseName"
    Me.lblBaseName.Size = New System.Drawing.Size(208, 16)
    Me.lblBaseName.TabIndex = 4
    Me.lblBaseName.Text = "Base Name"
    '
    'chkCreateXML
    '
    Me.chkCreateXML.Location = New System.Drawing.Point(16, 144)
    Me.chkCreateXML.Name = "chkCreateXML"
    Me.chkCreateXML.Size = New System.Drawing.Size(264, 16)
    Me.chkCreateXML.TabIndex = 2
    Me.chkCreateXML.Text = "Create XML Resource File"
    '
    'lblPictures
    '
    Me.lblPictures.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.lblPictures.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblPictures.Location = New System.Drawing.Point(344, 32)
    Me.lblPictures.Name = "lblPictures"
    Me.lblPictures.Size = New System.Drawing.Size(400, 16)
    Me.lblPictures.TabIndex = 7
    Me.lblPictures.Text = "Pictures"
    Me.lblPictures.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'lblTxtFname
    '
    Me.lblTxtFname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblTxtFname.Location = New System.Drawing.Point(16, 120)
    Me.lblTxtFname.Name = "lblTxtFname"
    Me.lblTxtFname.Size = New System.Drawing.Size(264, 16)
    Me.lblTxtFname.TabIndex = 1
    '
    'lblCulture
    '
    Me.lblCulture.Location = New System.Drawing.Point(16, 128)
    Me.lblCulture.Name = "lblCulture"
    Me.lblCulture.Size = New System.Drawing.Size(408, 16)
    Me.lblCulture.TabIndex = 0
    Me.lblCulture.Text = "Choose Culture"
    Me.lblCulture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'PictureBox1
    '
    Me.PictureBox1.Location = New System.Drawing.Point(288, 392)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(72, 40)
    Me.PictureBox1.TabIndex = 3
    Me.PictureBox1.TabStop = False
    '
    'cmdQuit
    '
    Me.cmdQuit.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
    Me.cmdQuit.Location = New System.Drawing.Point(712, 384)
    Me.cmdQuit.Name = "cmdQuit"
    Me.cmdQuit.Size = New System.Drawing.Size(75, 32)
    Me.cmdQuit.TabIndex = 2
    Me.cmdQuit.Text = "Quit"
    '
    'dgStringsStyle
    '
    Me.dgStringsStyle.DataGrid = Me.dgStrings
    Me.dgStringsStyle.MappingName = ""
    Me.dgStringsStyle.PreferredColumnWidth = 200
    Me.dgStringsStyle.SelectionForeColor = System.Drawing.Color.Red
    '
    'dgStrings
    '
    Me.dgStrings.DataMember = ""
    Me.dgStrings.Dock = System.Windows.Forms.DockStyle.Fill
    Me.dgStrings.Name = "dgStrings"
    Me.dgStrings.Size = New System.Drawing.Size(768, 334)
    Me.dgStrings.TabIndex = 0
    Me.dgStrings.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.dgStringsStyle})
    '
    'pic
    '
    Me.pic.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.pic.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
    Me.pic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.pic.Location = New System.Drawing.Point(216, 48)
    Me.pic.Name = "pic"
    Me.pic.Size = New System.Drawing.Size(116, 104)
    Me.pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.pic.TabIndex = 3
    Me.pic.TabStop = False
    '
    'sbStatus
    '
    Me.sbStatus.Location = New System.Drawing.Point(0, 433)
    Me.sbStatus.Name = "sbStatus"
    Me.sbStatus.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.spFile, Me.spStatus, Me.spDate})
    Me.sbStatus.ShowPanels = True
    Me.sbStatus.Size = New System.Drawing.Size(816, 24)
    Me.sbStatus.TabIndex = 1
    Me.sbStatus.Text = "StatusBar1"
    '
    'spFile
    '
    Me.spFile.Text = "File:"
    Me.spFile.Width = 500
    '
    'spStatus
    '
    Me.spStatus.Text = "Status:"
    '
    'spDate
    '
    Me.spDate.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
    Me.spDate.Text = "Date"
    Me.spDate.Width = 200
    '
    'tcResource
    '
    Me.tcResource.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.tcResource.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabPage1, Me.TabPage2, Me.TabPage3})
    Me.tcResource.Location = New System.Drawing.Point(16, 16)
    Me.tcResource.Name = "tcResource"
    Me.tcResource.SelectedIndex = 0
    Me.tcResource.Size = New System.Drawing.Size(776, 360)
    Me.tcResource.TabIndex = 0
    '
    'TabPage1
    '
    Me.TabPage1.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgStrings})
    Me.TabPage1.Location = New System.Drawing.Point(4, 22)
    Me.TabPage1.Name = "TabPage1"
    Me.TabPage1.Size = New System.Drawing.Size(768, 334)
    Me.TabPage1.TabIndex = 0
    Me.TabPage1.Text = "TexT"
    '
    'TabPage2
    '
    Me.TabPage2.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblPictures, Me.PicPanel, Me.lblPicKey, Me.lstPictures, Me.pic, Me.PictureBox1, Me.cmdDelPic, Me.cmdAddPic})
    Me.TabPage2.Location = New System.Drawing.Point(4, 22)
    Me.TabPage2.Name = "TabPage2"
    Me.TabPage2.Size = New System.Drawing.Size(768, 334)
    Me.TabPage2.TabIndex = 1
    Me.TabPage2.Text = "Pictures"
    '
    'PicPanel
    '
    Me.PicPanel.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.PicPanel.AutoScroll = True
    Me.PicPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.PicPanel.Location = New System.Drawing.Point(336, 48)
    Me.PicPanel.Name = "PicPanel"
    Me.PicPanel.Size = New System.Drawing.Size(408, 210)
    Me.PicPanel.TabIndex = 6
    '
    'lblPicKey
    '
    Me.lblPicKey.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblPicKey.Location = New System.Drawing.Point(32, 32)
    Me.lblPicKey.Name = "lblPicKey"
    Me.lblPicKey.Size = New System.Drawing.Size(176, 16)
    Me.lblPicKey.TabIndex = 5
    Me.lblPicKey.Text = "Key"
    Me.lblPicKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'lstPictures
    '
    Me.lstPictures.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.lstPictures.Location = New System.Drawing.Point(32, 48)
    Me.lstPictures.Name = "lstPictures"
    Me.lstPictures.Size = New System.Drawing.Size(176, 199)
    Me.lstPictures.TabIndex = 4
    '
    'cmdDelPic
    '
    Me.cmdDelPic.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
    Me.cmdDelPic.Location = New System.Drawing.Point(136, 270)
    Me.cmdDelPic.Name = "cmdDelPic"
    Me.cmdDelPic.TabIndex = 2
    Me.cmdDelPic.Text = "Remove"
    '
    'cmdAddPic
    '
    Me.cmdAddPic.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
    Me.cmdAddPic.Location = New System.Drawing.Point(32, 270)
    Me.cmdAddPic.Name = "cmdAddPic"
    Me.cmdAddPic.TabIndex = 1
    Me.cmdAddPic.Text = "Add"
    '
    'TabPage3
    '
    Me.TabPage3.Controls.AddRange(New System.Windows.Forms.Control() {Me.fraBasics, Me.fraOutput, Me.lstCultures, Me.lblCulture})
    Me.TabPage3.Location = New System.Drawing.Point(4, 22)
    Me.TabPage3.Name = "TabPage3"
    Me.TabPage3.Size = New System.Drawing.Size(768, 334)
    Me.TabPage3.TabIndex = 2
    Me.TabPage3.Text = "Final"
    '
    'fraBasics
    '
    Me.fraBasics.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblPicCnt, Me.lblNumPics, Me.lblStrCnt, Me.lblResStringNum, Me.lblInFilename, Me.lblInputFname})
    Me.fraBasics.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.fraBasics.Location = New System.Drawing.Point(16, 16)
    Me.fraBasics.Name = "fraBasics"
    Me.fraBasics.Size = New System.Drawing.Size(408, 100)
    Me.fraBasics.TabIndex = 12
    Me.fraBasics.TabStop = False
    Me.fraBasics.Text = "Basics"
    '
    'lblNumPics
    '
    Me.lblNumPics.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblNumPics.Location = New System.Drawing.Point(216, 72)
    Me.lblNumPics.Name = "lblNumPics"
    Me.lblNumPics.Size = New System.Drawing.Size(48, 16)
    Me.lblNumPics.TabIndex = 1
    '
    'lblStrCnt
    '
    Me.lblStrCnt.Location = New System.Drawing.Point(16, 56)
    Me.lblStrCnt.Name = "lblStrCnt"
    Me.lblStrCnt.Size = New System.Drawing.Size(176, 16)
    Me.lblStrCnt.TabIndex = 0
    Me.lblStrCnt.Text = "String Count"
    '
    'lblResStringNum
    '
    Me.lblResStringNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblResStringNum.Location = New System.Drawing.Point(16, 72)
    Me.lblResStringNum.Name = "lblResStringNum"
    Me.lblResStringNum.Size = New System.Drawing.Size(48, 16)
    Me.lblResStringNum.TabIndex = 1
    '
    'lblInFilename
    '
    Me.lblInFilename.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblInFilename.Location = New System.Drawing.Point(16, 32)
    Me.lblInFilename.Name = "lblInFilename"
    Me.lblInFilename.Size = New System.Drawing.Size(376, 16)
    Me.lblInFilename.TabIndex = 1
    '
    'lblInputFname
    '
    Me.lblInputFname.Location = New System.Drawing.Point(16, 16)
    Me.lblInputFname.Name = "lblInputFname"
    Me.lblInputFname.Size = New System.Drawing.Size(376, 16)
    Me.lblInputFname.TabIndex = 0
    Me.lblInputFname.Text = "Input Filename"
    '
    'fraOutput
    '
    Me.fraOutput.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdSave, Me.lblBaseName, Me.txtBaseName, Me.chkCreateBin, Me.chkCreateXML, Me.chkCreateText, Me.lblBinFname, Me.lblXMLfname, Me.lblTxtFname})
    Me.fraOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.fraOutput.Location = New System.Drawing.Point(448, 16)
    Me.fraOutput.Name = "fraOutput"
    Me.fraOutput.Size = New System.Drawing.Size(296, 288)
    Me.fraOutput.TabIndex = 10
    Me.fraOutput.TabStop = False
    Me.fraOutput.Text = "Build Output File(s)"
    '
    'cmdSave
    '
    Me.cmdSave.Location = New System.Drawing.Point(208, 240)
    Me.cmdSave.Name = "cmdSave"
    Me.cmdSave.Size = New System.Drawing.Size(75, 32)
    Me.cmdSave.TabIndex = 5
    Me.cmdSave.Text = "Save"
    '
    'txtBaseName
    '
    Me.txtBaseName.Location = New System.Drawing.Point(32, 48)
    Me.txtBaseName.Name = "txtBaseName"
    Me.txtBaseName.Size = New System.Drawing.Size(208, 20)
    Me.txtBaseName.TabIndex = 3
    Me.txtBaseName.Text = ""
    '
    'chkCreateBin
    '
    Me.chkCreateBin.Location = New System.Drawing.Point(16, 192)
    Me.chkCreateBin.Name = "chkCreateBin"
    Me.chkCreateBin.Size = New System.Drawing.Size(264, 16)
    Me.chkCreateBin.TabIndex = 2
    Me.chkCreateBin.Text = "Create Binary Resource File"
    '
    'chkCreateText
    '
    Me.chkCreateText.Location = New System.Drawing.Point(16, 104)
    Me.chkCreateText.Name = "chkCreateText"
    Me.chkCreateText.Size = New System.Drawing.Size(264, 16)
    Me.chkCreateText.TabIndex = 2
    Me.chkCreateText.Text = "Create Text file for translator"
    '
    'lblBinFname
    '
    Me.lblBinFname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblBinFname.Location = New System.Drawing.Point(16, 208)
    Me.lblBinFname.Name = "lblBinFname"
    Me.lblBinFname.Size = New System.Drawing.Size(264, 16)
    Me.lblBinFname.TabIndex = 1
    '
    'lblXMLfname
    '
    Me.lblXMLfname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblXMLfname.Location = New System.Drawing.Point(16, 160)
    Me.lblXMLfname.Name = "lblXMLfname"
    Me.lblXMLfname.Size = New System.Drawing.Size(264, 16)
    Me.lblXMLfname.TabIndex = 1
    '
    'lstCultures
    '
    Me.lstCultures.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lstCultures.ItemHeight = 14
    Me.lstCultures.Location = New System.Drawing.Point(16, 144)
    Me.lstCultures.Name = "lstCultures"
    Me.lstCultures.Size = New System.Drawing.Size(408, 158)
    Me.lstCultures.TabIndex = 4
    '
    'mnuFile
    '
    Me.mnuFile.Index = 0
    Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuOpen, Me.mnuAppend, Me.mnuExit})
    Me.mnuFile.Text = "File"
    '
    'mnuOpen
    '
    Me.mnuOpen.Index = 0
    Me.mnuOpen.Text = "Open"
    '
    'mnuAppend
    '
    Me.mnuAppend.Index = 1
    Me.mnuAppend.Text = "Append"
    '
    'mnuExit
    '
    Me.mnuExit.Index = 2
    Me.mnuExit.Text = "Exit"
    '
    'MainMenu1
    '
    Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile})
    '
    'frmResEdit
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(816, 457)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdQuit, Me.sbStatus, Me.tcResource})
    Me.Menu = Me.MainMenu1
    Me.Name = "frmResEdit"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Resource Editor"
    CType(Me.dgStrings, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.spFile, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.spStatus, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.spDate, System.ComponentModel.ISupportInitialize).EndInit()
    Me.tcResource.ResumeLayout(False)
    Me.TabPage1.ResumeLayout(False)
    Me.TabPage2.ResumeLayout(False)
    Me.TabPage3.ResumeLayout(False)
    Me.fraBasics.ResumeLayout(False)
    Me.fraOutput.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region

  Const GridLineWidth As Integer = 1 'Pixel width of a grid line
  'These names do not need to be in a resource file because they will 
  'never be seen by the user.
  Const ResourceTableName As String = "Resources"

  Const TEXT_TAB As Integer = 0
  Const GRAPHICS_TAB As Integer = 1
  Const FINAL_TAB As Integer = 2
  Const PICSPACE As Int16 = 10
  Const PICSIZE As Int16 = 64

  Private m_StringTable As DataTable
  Private m_ResFile As String
  Private m_NewFname As String
  Private m_ResType As ResTypes
  Private m_Pictures As New Collection()

  Private Sub Form1_Load(ByVal sender As System.Object, _
                         ByVal e As System.EventArgs) Handles MyBase.Load

    'Thread.CurrentThread.CurrentCulture = New CultureInfo("de-DE")
    'Thread.CurrentThread.CurrentUICulture = New CultureInfo("de-DE")

    InitStrings()

    SetupStringTable()
    dgStrings.DataSource = m_StringTable
    SetupStringResourceGrid()
    AlignColumns()

  End Sub

  Private Sub InitStrings()

    rm = New ResourceManager("ResEditor", Me.GetType().Assembly)

    'Status Panel
    sbStatus.Panels(2).Text = Now.ToString
    sbStatus.Panels(1).Width = 100

    'Tab Pages
    tcResource.TabPages(TEXT_TAB).Text = rm.GetString("TEXT")
    tcResource.TabPages(GRAPHICS_TAB).Text = rm.GetString("PICTURES")
    tcResource.TabPages(FINAL_TAB).Text = rm.GetString("FINAL")

    'Form Controls
    cmdQuit.Text = rm.GetString("QUIT")
    mnuFile.Text = rm.GetString("FILE")
    mnuOpen.Text = rm.GetString("OPEN")
    mnuAppend.Text = rm.GetString("APPEND")
    mnuExit.Text = rm.GetString("EXIT")

    'do picture tab
    lblPicKey.Text = rm.GetString("KEY")
    lblPictures.Text = rm.GetString("PICTURES")
    cmdAddPic.Text = rm.GetString("ADD")
    cmdDelPic.Text = rm.GetString("REMOVE")

    'Do Final tab
    fraBasics.Text = rm.GetString("BASICS")
    lblInputFname.Text = rm.GetString("INPUT FNAME")
    lblStrCnt.Text = rm.GetString("STRING COUNT")
    lblPicCnt.Text = rm.GetString("PIC COUNT")
    lblCulture.Text = rm.GetString("CULTURE")
    fraOutput.Text = rm.GetString("OUTPUT")
    lblBaseName.Text = rm.GetString("BASE NAME")
    cmdSave.Text = rm.GetString("SAVE")
    chkCreateText.Text = rm.GetString("CREATE TEXT")
    chkCreateXML.Text = rm.GetString("CREATE XML")
    chkCreateBin.Text = rm.GetString("CREATE BIN")

    Me.Icon = CType(rm.GetObject("Flag"), Icon)

  End Sub
  Private Sub AlignColumns()

    dgStrings.TableStyles(0).GridColumnStyles(0).Width = 100
    dgStrings.TableStyles(0).GridColumnStyles(1).Width = 300
    dgStrings.TableStyles(0).GridColumnStyles(2).Width = _
          dgStrings.Size.Width - dgStrings.TableStyles(0).GridColumnStyles(0). _
          Width - dgStrings.TableStyles(0).GridColumnStyles(1).Width - _
          dgStrings.RowHeaderWidth - 4 * GridLineWidth

  End Sub
  Private Sub SetupStringResourceGrid()
    Dim dgS As New DataGridTableStyle()
    Dim dgCKey As DataGridTextBoxColumn
    Dim dgCText As DataGridTextBoxColumn
    Dim dgCComment As DataGridTextBoxColumn


    'Set up a table style first then add it to the grid
    dgS.MappingName = ResourceTableName
    dgS.PreferredColumnWidth = 300
    dgS.SelectionBackColor = Color.Beige
    dgS.SelectionForeColor = Color.Black
    dgS.AllowSorting = True

    'Make a column style for the first column and add it to the columnstyle
    dgCKey = New DataGridTextBoxColumn()
    dgCKey.MappingName = KeyCol
    dgCKey.HeaderText = rm.GetString("RESKEY")
    dgCKey.Width = 100
    dgS.GridColumnStyles.Add(dgCKey)

    'Make a column style for the second column and add it to the columnstyle
    dgCComment = New DataGridTextBoxColumn()
    dgCComment.MappingName = TextCol
    dgCComment.HeaderText = rm.GetString("RESTEXT")
    dgCComment.Width = 300
    dgS.GridColumnStyles.Add(dgCComment)

    'Make a column style for the third column and add it to the columnstyle
    dgCText = New DataGridTextBoxColumn()
    dgCText.MappingName = CommentCol
    dgCText.HeaderText = rm.GetString("COMMENT")
    dgCText.Width = 400
    dgS.GridColumnStyles.Add(dgCText)

    'First purge all table styles from this grid then add the one that I want
    dgStrings.TableStyles.Clear()
    dgStrings.TableStyles.Add(dgS)

  End Sub
  Private Sub SetupStringTable()
    Dim dr As DataRow

    'Give this table a name so I can synchronize to it with the grid
    m_StringTable = New DataTable(ResourceTableName)

    'Add three columns to the table
    m_StringTable.Columns.Add(New DataColumn(KeyCol, _
                              Type.GetType("System.String")))
    m_StringTable.Columns.Add(New DataColumn(TextCol, _
                              Type.GetType("System.String")))
    m_StringTable.Columns.Add(New DataColumn(CommentCol, _
                              Type.GetType("System.String")))

  End Sub
  Private Sub ProgExit(ByVal sender As System.Object, _
                       ByVal e As System.EventArgs) Handles cmdQuit.Click, _
                                                    mnuExit.Click
    Me.Dispose()
    End
  End Sub



  '========= Tab 1&2 =================
  Private Sub FillPicList()
    Dim ResImg As ResImage

    PicPanel.AutoScroll = True
    pic.Image = Nothing
    For Each ResImg In m_Pictures
      lstPictures.Items.Add(ResImg.Name)
      'Make a new picture box and add it to the 
      'panels control array
      AddPic2Panel(ResImg)
    Next
    ArrangePictures()

    If lstPictures.Items.Count > 0 Then
      lstPictures.SetSelected(0, True)
      cmdDelPic.Enabled = True
    Else
      cmdDelPic.Enabled = False
    End If

  End Sub
  Private Sub AddPic2Panel(ByVal ResImg As ResImage)
    Dim Pic As PictureBox

    Pic = New PictureBox()
    Pic.Size = New Size(PICSIZE, PICSIZE)
    Pic.Location = New Point(10, 10)
    Pic.SizeMode = PictureBoxSizeMode.StretchImage
    Pic.Image = ResImg.Image
    Pic.Tag = ResImg.Name
    PicPanel.Controls.Add(Pic)

  End Sub
  Private Sub ArrangePictures()
    Dim k As Int32
    Dim x As Int32
    Dim y As Int32

    'Number of pictures in a row.
    'DO not show a picture if it means we get a horizontal
    'scroll bar
    Dim NumPicsInWidth As Int32 = CType(((PicPanel.Size.Width - PICSPACE) / _
                                          (PICSIZE + PICSPACE)) - 1, Int32)
    'Control collections are zero based.
    'VB type collections are 1 based.
    For k = 0 To PicPanel.Controls.Count - 1
      'determine if we are in a new row
      If k Mod (NumPicsInWidth) = 0 Then
        x = PICSPACE
      Else
        x = PicPanel.Controls(k - 1).Location.X + PICSIZE + PICSPACE
      End If

      If k < NumPicsInWidth Then
        y = PICSPACE
      ElseIf k Mod (NumPicsInWidth) = 0 Then
        y = PicPanel.Controls(k - 1).Location.Y + PICSIZE + PICSPACE
      End If

      PicPanel.Controls(k).Location = New Point(x, y)
    Next

  End Sub
  Private Sub GetResources(ByVal sender As Object, ByVal e As System.EventArgs) _
                            Handles mnuOpen.Click, mnuAppend.Click

    OpenResFile.Reset()
    OpenResFile.InitialDirectory = Directory.GetCurrentDirectory()
    OpenResFile.RestoreDirectory = True
    OpenResFile.Filter = "Text files (*.txt)|*.txt|XML files " + _
                          "(*.resx)|*.resx|Binary files" + _
                          "(*.resources)|*.resources"

    If (OpenResFile.ShowDialog() = DialogResult.OK) Then
      m_ResType = CType(OpenResFile.FilterIndex, ResTypes)
      m_ResFile = OpenResFile.FileName
      Dim Res As New ResUtil(m_ResFile, m_ResType)

      'clear the pictures
      lstPictures.Items.Clear()
      'In Beta 2 the clear function for the listbox does not work correctly
      'So do it the hard way
      While lstPictures.Items.Count > 0
        lstPictures.Items.Remove(1)
      End While
      PicPanel.Controls.Clear()

      'Fill the string text box
      sbStatus.Panels(0).Text = m_ResFile
      If sender Is mnuOpen Then
        Res.GetData(m_StringTable, False)
        m_Pictures = Res.Pics
      ElseIf sender Is mnuAppend Then
        Res.GetData(m_StringTable, True)
        'Add to the pictures collection
        Dim NewPics As New Collection()
        Dim p As ResImage
        NewPics = Res.Pics
        For Each p In NewPics
          m_Pictures.Add(p)
        Next
      End If

      FillPicList()

    End If

  End Sub
  Private Sub PicList(ByVal sender As System.Object, _
                      ByVal e As System.EventArgs) _
                      Handles lstPictures.SelectedIndexChanged
    Dim rImg As ResImage

    rImg = CType(m_Pictures.Item(lstPictures.SelectedItem.ToString), ResImage)
    pic.Image = rImg.Image

    'Highlight the picture in question by
    'giving it a border.  Don't foget to "unborder" the others.
    Dim pb As PictureBox
    For Each pb In PicPanel.Controls
      If pb.Tag.ToString = rImg.Name Then
        pb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
      Else
        pb.BorderStyle = System.Windows.Forms.BorderStyle.None
      End If
    Next

  End Sub
  Private Sub RemovePic(ByVal sender As System.Object, _
                        ByVal e As System.EventArgs) Handles cmdDelPic.Click

    'Remove the picture from the pictures collection
    m_Pictures.Remove(lstPictures.SelectedItem.ToString)

    'Remove the picture from the panel and rearrange the rest
    Dim pb As PictureBox
    For Each pb In PicPanel.Controls
      If pb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle Then
        PicPanel.Controls.Remove(pb)
        ArrangePictures()
        Exit For
      End If
    Next

    'Remove the name from the listbox of keys and 
    'reselect the first one
    lstPictures.Items.Remove(lstPictures.SelectedItem)
    If lstPictures.Items.Count > 0 Then
      lstPictures.SetSelected(0, True)
    Else
      cmdDelPic.Enabled = False
      pic.Image = Nothing
    End If

  End Sub
  Private Sub AddPic(ByVal sender As System.Object, _
                      ByVal e As System.EventArgs) Handles cmdAddPic.Click
    Dim rImg As ResImage

    OpenResFile.Reset()
    OpenResFile.InitialDirectory = Directory.GetCurrentDirectory()
    OpenResFile.RestoreDirectory = True
    OpenResFile.Filter = "Picture files " + _
                 "(*.jpg; *.bmp; *.gif; *.ico)|*.jpg; *.bmp; *.gif; *.ico"

    If (OpenResFile.ShowDialog() = DialogResult.OK) Then
      Dim fInfo As New FileInfo(OpenResFile.FileName)
      If fInfo.Extension.ToUpper = ".JPG" Or _
          fInfo.Extension.ToUpper = ".BMP" Or _
          fInfo.Extension.ToUpper = ".ICO" Or _
          fInfo.Extension.ToUpper = ".GIF" Then
        'Add the picture to the collection
        If fInfo.Extension.ToUpper = ".ICO" Then
          rImg = New ResImage(OpenResFile.FileName, _
                                   New Icon(OpenResFile.FileName))
        Else
          rImg = New ResImage(OpenResFile.FileName, _
                                   Image.FromFile(OpenResFile.FileName))
        End If
        Dim Keyform As New AskKey(rImg)
        If Keyform.ShowDialog(Me) = DialogResult.OK Then
          m_Pictures.Add(rImg, rImg.Name)
          'Add the picture to the panel and arrange
          AddPic2Panel(rImg)
          ArrangePictures()
          'Add the picture to the list and enable delete and select it
          lstPictures.Items.Add(rImg.Name)
          lstPictures.SetSelected(lstPictures.Items.Count - 1, True)
          cmdDelPic.Enabled = True
        End If
        Keyform.Dispose()
      End If
    End If

  End Sub



  '========= Tab 3 ===========
  Private Sub tcResource_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs) _
                              Handles tcResource.Click, _
                              tcResource.SelectedIndexChanged, _
                              tcResource.DoubleClick

    If tcResource.SelectedIndex = FINAL_TAB Then
      lblInFilename.Text = m_ResFile
      lblResStringNum.Text = m_StringTable.Rows.Count.ToString
      lblNumPics.Text = m_Pictures.Count.ToString

      Dim AllCultures() As CultureInfo
      Dim ACulture As CultureInfo
      AllCultures = CultureInfo.GetCultures(CultureTypes.InstalledWin32Cultures)
      lstCultures.Items.Clear()
      lstCultures.Items.Add(" ".PadRight(10) + "(None)")
      lstCultures.Sorted = True
      For Each ACulture In AllCultures
        lstCultures.Items.Add(ACulture.Name.PadRight(15) + ACulture.NativeName)
      Next
      chkCreateBin.Checked = True
    End If
    If tcResource.SelectedIndex = GRAPHICS_TAB Then
      If lstPictures.Items.Count < 1 Then
        cmdDelPic.Enabled = False
      End If

    End If

  End Sub

  Private Sub BuildCompleteName()

    m_NewFname = CStr(IIf(txtBaseName.Text = "", "?", txtBaseName.Text))
    If Not lstCultures.SelectedItem Is Nothing Then
      If lstCultures.SelectedItem.ToString.Trim <> "(None)" Then
        m_NewFname += "." + MS.Left(lstCultures.SelectedItem.ToString, 15).Trim
      End If
    End If

    If chkCreateText.Checked = True Then
      lblTxtFname.Text = m_NewFname + ".txt"
    Else
      lblTxtFname.Text = ""
    End If
    If chkCreateXML.Checked = True Then
      lblXMLfname.Text = m_NewFname + ".resx"
    Else
      lblXMLfname.Text = ""
    End If
    If chkCreateBin.Checked = True Then
      lblBinFname.Text = m_NewFname + ".resources"
    Else
      lblBinFname.Text = ""
    End If

  End Sub

  Private Sub CulturePick(ByVal sender As System.Object, _
                          ByVal e As System.EventArgs) _
                          Handles lstCultures.SelectedIndexChanged
    BuildCompleteName()
  End Sub

  Private Sub Create_Checked(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs) _
                             Handles chkCreateText.CheckedChanged, _
                             chkCreateXML.CheckedChanged, _
                             chkCreateBin.CheckedChanged

    If chkCreateBin.Checked = False And chkCreateXML.Checked = False And _
                                        chkCreateText.Checked = False Then
      cmdSave.Enabled = False
    Else
      cmdSave.Enabled = True
    End If
    BuildCompleteName()

  End Sub

  Private Sub txtBaseName_TextChanged_1(ByVal sender As System.Object, _
                                        ByVal e As System.EventArgs) _
                                        Handles txtBaseName.TextChanged
    BuildCompleteName()
  End Sub

  Private Sub cmdSave_Click(ByVal sender As System.Object, _
                            ByVal e As System.EventArgs) Handles cmdSave.Click
    Dim Res As New ResUtil(m_ResFile)

    Res.OutputFileName = m_NewFname

    If chkCreateText.Checked Then
      Res.SaveData(m_StringTable, m_Pictures, Consts.ResTypes.TextType)
    End If
    If chkCreateXML.Checked Then
      Res.SaveData(m_StringTable, m_Pictures, Consts.ResTypes.XMLType)
    End If
    If chkCreateBin.Checked Then
      Res.SaveData(m_StringTable, m_Pictures, Consts.ResTypes.BinType)
    End If

  End Sub



End Class
