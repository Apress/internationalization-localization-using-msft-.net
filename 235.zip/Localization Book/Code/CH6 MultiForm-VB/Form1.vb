
Imports System.Globalization
Imports System.Threading

Public Class Form1
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

    Thread.CurrentThread.CurrentUICulture = New CultureInfo("az-AZ-Cyrl")

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
   Friend WithEvents Button1 As System.Windows.Forms.Button

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.Container

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
    Me.TextBox1 = New System.Windows.Forms.TextBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Button1 = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'TextBox1
    '
    Me.TextBox1.AccessibleDescription = CType(resources.GetObject("TextBox1.AccessibleDescription"), String)
    Me.TextBox1.AccessibleName = CType(resources.GetObject("TextBox1.AccessibleName"), String)
    Me.TextBox1.Anchor = CType(resources.GetObject("TextBox1.Anchor"), System.Windows.Forms.AnchorStyles)
    Me.TextBox1.AutoSize = CType(resources.GetObject("TextBox1.AutoSize"), Boolean)
    Me.TextBox1.BackgroundImage = CType(resources.GetObject("TextBox1.BackgroundImage"), System.Drawing.Image)
    Me.TextBox1.Dock = CType(resources.GetObject("TextBox1.Dock"), System.Windows.Forms.DockStyle)
    Me.TextBox1.Enabled = CType(resources.GetObject("TextBox1.Enabled"), Boolean)
    Me.TextBox1.Font = CType(resources.GetObject("TextBox1.Font"), System.Drawing.Font)
    Me.TextBox1.ImeMode = CType(resources.GetObject("TextBox1.ImeMode"), System.Windows.Forms.ImeMode)
    Me.TextBox1.Location = CType(resources.GetObject("TextBox1.Location"), System.Drawing.Point)
    Me.TextBox1.MaxLength = CType(resources.GetObject("TextBox1.MaxLength"), Integer)
    Me.TextBox1.Multiline = CType(resources.GetObject("TextBox1.Multiline"), Boolean)
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.PasswordChar = CType(resources.GetObject("TextBox1.PasswordChar"), Char)
    Me.TextBox1.RightToLeft = CType(resources.GetObject("TextBox1.RightToLeft"), System.Windows.Forms.RightToLeft)
    Me.TextBox1.ScrollBars = CType(resources.GetObject("TextBox1.ScrollBars"), System.Windows.Forms.ScrollBars)
    Me.TextBox1.Size = CType(resources.GetObject("TextBox1.Size"), System.Drawing.Size)
    Me.TextBox1.TabIndex = CType(resources.GetObject("TextBox1.TabIndex"), Integer)
    Me.TextBox1.Text = resources.GetString("TextBox1.Text")
    Me.TextBox1.TextAlign = CType(resources.GetObject("TextBox1.TextAlign"), System.Windows.Forms.HorizontalAlignment)
    Me.TextBox1.Visible = CType(resources.GetObject("TextBox1.Visible"), Boolean)
    Me.TextBox1.WordWrap = CType(resources.GetObject("TextBox1.WordWrap"), Boolean)
    '
    'Label1
    '
    Me.Label1.AccessibleDescription = CType(resources.GetObject("Label1.AccessibleDescription"), String)
    Me.Label1.AccessibleName = CType(resources.GetObject("Label1.AccessibleName"), String)
    Me.Label1.Anchor = CType(resources.GetObject("Label1.Anchor"), System.Windows.Forms.AnchorStyles)
    Me.Label1.AutoSize = CType(resources.GetObject("Label1.AutoSize"), Boolean)
    Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label1.Dock = CType(resources.GetObject("Label1.Dock"), System.Windows.Forms.DockStyle)
    Me.Label1.Enabled = CType(resources.GetObject("Label1.Enabled"), Boolean)
    Me.Label1.Font = CType(resources.GetObject("Label1.Font"), System.Drawing.Font)
    Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
    Me.Label1.ImageAlign = CType(resources.GetObject("Label1.ImageAlign"), System.Drawing.ContentAlignment)
    Me.Label1.ImageIndex = CType(resources.GetObject("Label1.ImageIndex"), Integer)
    Me.Label1.ImeMode = CType(resources.GetObject("Label1.ImeMode"), System.Windows.Forms.ImeMode)
    Me.Label1.Location = CType(resources.GetObject("Label1.Location"), System.Drawing.Point)
    Me.Label1.Name = "Label1"
    Me.Label1.RightToLeft = CType(resources.GetObject("Label1.RightToLeft"), System.Windows.Forms.RightToLeft)
    Me.Label1.Size = CType(resources.GetObject("Label1.Size"), System.Drawing.Size)
    Me.Label1.TabIndex = CType(resources.GetObject("Label1.TabIndex"), Integer)
    Me.Label1.Text = resources.GetString("Label1.Text")
    Me.Label1.TextAlign = CType(resources.GetObject("Label1.TextAlign"), System.Drawing.ContentAlignment)
    Me.Label1.Visible = CType(resources.GetObject("Label1.Visible"), Boolean)
    '
    'Button1
    '
    Me.Button1.AccessibleDescription = CType(resources.GetObject("Button1.AccessibleDescription"), String)
    Me.Button1.AccessibleName = CType(resources.GetObject("Button1.AccessibleName"), String)
    Me.Button1.Anchor = CType(resources.GetObject("Button1.Anchor"), System.Windows.Forms.AnchorStyles)
    Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
    Me.Button1.Dock = CType(resources.GetObject("Button1.Dock"), System.Windows.Forms.DockStyle)
    Me.Button1.Enabled = CType(resources.GetObject("Button1.Enabled"), Boolean)
    Me.Button1.FlatStyle = CType(resources.GetObject("Button1.FlatStyle"), System.Windows.Forms.FlatStyle)
    Me.Button1.Font = CType(resources.GetObject("Button1.Font"), System.Drawing.Font)
    Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
    Me.Button1.ImageAlign = CType(resources.GetObject("Button1.ImageAlign"), System.Drawing.ContentAlignment)
    Me.Button1.ImageIndex = CType(resources.GetObject("Button1.ImageIndex"), Integer)
    Me.Button1.ImeMode = CType(resources.GetObject("Button1.ImeMode"), System.Windows.Forms.ImeMode)
    Me.Button1.Location = CType(resources.GetObject("Button1.Location"), System.Drawing.Point)
    Me.Button1.Name = "Button1"
    Me.Button1.RightToLeft = CType(resources.GetObject("Button1.RightToLeft"), System.Windows.Forms.RightToLeft)
    Me.Button1.Size = CType(resources.GetObject("Button1.Size"), System.Drawing.Size)
    Me.Button1.TabIndex = CType(resources.GetObject("Button1.TabIndex"), Integer)
    Me.Button1.Text = resources.GetString("Button1.Text")
    Me.Button1.TextAlign = CType(resources.GetObject("Button1.TextAlign"), System.Drawing.ContentAlignment)
    Me.Button1.Visible = CType(resources.GetObject("Button1.Visible"), Boolean)
    '
    'Form1
    '
    Me.AccessibleDescription = CType(resources.GetObject("$this.AccessibleDescription"), String)
    Me.AccessibleName = CType(resources.GetObject("$this.AccessibleName"), String)
    Me.Anchor = CType(resources.GetObject("$this.Anchor"), System.Windows.Forms.AnchorStyles)
    Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
    Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
    Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
    Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
    Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
    Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button1, Me.TextBox1, Me.Label1})
    Me.Dock = CType(resources.GetObject("$this.Dock"), System.Windows.Forms.DockStyle)
    Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
    Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
    Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
    Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
    Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
    Me.Name = "Form1"
    Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
    Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
    Me.Text = resources.GetString("$this.Text")
    Me.Visible = CType(resources.GetObject("$this.Visible"), Boolean)
    Me.ResumeLayout(False)

  End Sub

#End Region

   Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


   End Sub
End Class
