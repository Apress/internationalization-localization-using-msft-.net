using System;
using System.Globalization;
using System.Threading;


namespace Ch7Numberformat_C
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{

      CultureInfo FRCulture = new CultureInfo("fr-FR");
      CultureInfo MyCulture = new CultureInfo(Thread. 
                                       CurrentThread. 
                                       CurrentUICulture. 
                                       LCID);
      NumberFormatInfo Vnf = new NumberFormatInfo();

      Console.WriteLine(123456.ToString("c", MyCulture));

      Vnf = MyCulture.NumberFormat;
      Vnf.CurrencyDecimalSeparator = ",";
      Vnf.CurrencyGroupSeparator = ".";
      Vnf.NumberDecimalSeparator = ",";
      Vnf.NumberGroupSeparator = ".";
      MyCulture.NumberFormat = Vnf;

      Console.WriteLine(123456.ToString("C", MyCulture));

      MyCulture.NumberFormat = FRCulture.NumberFormat;
      Console.WriteLine(123456.ToString("c", MyCulture));





      Console.ReadLine();
      }
	}
}
