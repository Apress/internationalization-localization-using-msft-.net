Imports System
Imports System.Globalization

Module Module1

    Sub Main()
      Dim MyCalendar As Calendar = New GregorianCalendar()
      'Dim MyCalendar As Calendar = New HebrewCalendar()
      Dim MyDate As New DateTime(2001, 8, 22, 15, 30, 0, 0)
      Dim MyCulture As CultureInfo = New CultureInfo("es-ES")

      'ToDateTime is not culture aware
      Console.WriteLine(MyCalendar.ToDateTime(MyDate.Year, _
                     MyDate.Month, MyDate.Day, MyDate.Hour, _
                     MyDate.Minute, 0, 0))

      'Remeber these are objects so use the ToString() method 
      'to make it culture aware
      Console.WriteLine(MyCalendar.AddMinutes(MyDate, _
                           15).ToString("G", MyCulture))

      'See what the last 2 digit year you can use to represent 
      'this century
      Console.WriteLine(MyCalendar.TwoDigitYearMax)
      'This should be 1932 in Gregorian
      Console.WriteLine(MyCalendar.ToFourDigitYear(32))
      'This should be 2028 in Gregorian
      Console.WriteLine(MyCalendar.ToFourDigitYear(28))


      Console.ReadLine()
    End Sub

End Module
