Imports System.Globalization

Module Module1

   Sub Main()

      Dim MyStr, OutBuf As String
      Dim Iter As TextElementEnumerator

      MyStr = "The quick programmer ran rings around the lazy manager"

      'Lets go the iteration route
      Iter = StringInfo.GetTextElementEnumerator(MyStr)
      Do While (Iter.MoveNext)
         OutBuf = "Character at position " + _
                  Iter.ElementIndex.ToString() + _
                  " = " + Iter.Current
         Console.WriteLine(OutBuf)
      Loop

      'Lets do the manual loop route
      Dim k As Int16
      For k = 0 To Len(MyStr) - 1
         OutBuf = "Character at position " + _
                  k.ToString + " = " + _
                  StringInfo.GetNextTextElement(MyStr, k)
         Console.WriteLine(OutBuf)
      Next

      'Lets do the mid$ thing
      Dim j As Int16
      For j = 1 To Len(MyStr)
         OutBuf = "Character at position " + _
                  j.ToString + " = " + _
                  Mid(MyStr, j, 1)
         Console.WriteLine(OutBuf)
      Next

      Console.ReadLine()
   End Sub

End Module
