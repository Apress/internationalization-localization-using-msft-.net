using System;
using System.Resources;
using System.Collections;

namespace CH5ResourceReader_C
{
  /// <summary>
  ///  Simple resource dump program
  /// </summary>
  class Class1
  {
    static void Main(string[] args)
    {
      //Open a resource reader and get an enumerator from it
      IResourceReader reader = new ResourceReader("ch5RR.resources");
      IDictionaryEnumerator en = reader.GetEnumerator();

      while (en.MoveNext()) 
      {
        Console.WriteLine("Name: {0} - Value: {1}", 
                  en.Key.ToString().PadRight(10, ' '), 
                  en.Value);
      }
      reader.Close();

      //Loose resource example
      ResourceManager rm;
      rm = ResourceManager.CreateFileBasedResourceManager("ch5rr",".",null);
      Console.WriteLine(rm.GetString("first"));


      Console.ReadLine();
    }
  }
}
