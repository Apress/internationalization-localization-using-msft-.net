using System;
using System.Globalization;
using Microsoft.VisualBasic;

namespace CH4StringInfo_C
{
	/// <summary>
	/// StringInfo demonstration
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
         TextElementEnumerator Iter;
         String MyStr, OutBuf;

         MyStr = "The Quick programmer ran rings around the lazy manager";

         //Lets do the iterator thing
         Iter = StringInfo.GetTextElementEnumerator(MyStr);
         while (Iter.MoveNext())
         {
            OutBuf = "Character at position " + 
                     Iter.ElementIndex.ToString() + 
                     " = " + Iter.Current;
            Console.WriteLine(OutBuf);
         }
         
         //Lets do the manual loop thing
         for (int k=0; k<MyStr.Length; k++)
         {
            OutBuf = "Character at position " + 
                        k.ToString() + " = " + 
                        StringInfo.GetNextTextElement(MyStr, k);
            Console.WriteLine(OutBuf);
         }

         //Lets do the Visual Basic MID$ thing.
         for (int j=1; j<MyStr.Length+1; j++)
         {
            OutBuf = "Character at position " + j.ToString() + 
                     " = " + Strings.Mid(MyStr, j, 1);
            Console.WriteLine(OutBuf);
         }

         Console.ReadLine();
      }
	}
}
