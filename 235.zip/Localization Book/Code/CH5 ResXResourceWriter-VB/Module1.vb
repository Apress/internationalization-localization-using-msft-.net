Imports System
Imports System.Resources
Imports System.Drawing

Module Module1

  Sub Main()
    Dim RwX As New ResXResourceWriter("CH5Rwx.resx")
    Dim RrX As ResXResourceReader
    Dim RrXEn As IDictionaryEnumerator

    RwX.AddResource("key 1", "First value")
    RwX.AddResource("key 2", "Second value")
    RwX.AddResource("key 3", "Third value")

    'Add a picture to the file
    Dim img = Image.FromFile("crane.jpg")
    RwX.AddResource("crane", img)

    RwX.Generate()
    RwX.Close()

    RrX = New ResXResourceReader("CH5Rwx.resx")
    RrXEn = RrX.GetEnumerator
    Do While (RrXEn.MoveNext)
      Console.WriteLine("Name: {0} - Value: {1}", _
                  RrXEn.Key.ToString().PadRight(10, " "c), _
                  RrXEn.Value)
    Loop
    RrX.Close()

    Console.ReadLine()
  End Sub

End Module
